# KeyMapper Pro

Mapeador de teclado e mouse para jogos Android (foco em Free Fire). Kotlin · Jetpack Compose · Material 3 · Room · DataStore · Shizuku API · Foreground Service · Accessibility Service.

> **Status honesto:** o código foi escrito e revisado estaticamente, mas **não foi compilado nem testado em aparelho** (o ambiente de criação não tem Android SDK). Espere corrigir um ou outro erro de compilação no primeiro build.

## Como compilar

**Android Studio (recomendado)**
1. Instale o Android Studio (Ladybug ou mais novo) e o JDK 17 (já vem junto).
2. *File → Open* → pasta `KeyMapperPro`. Aguarde a sincronização do Gradle (baixa dependências).
3. *Build → Build APK(s)* → o APK sai em `app/build/outputs/apk/debug/`.
4. Terminal: `./gradlew assembleDebug` (debug) ou `./gradlew assembleRelease` (assinado com a chave debug, só para teste).

**Sem instalar nada:** suba a pasta para um repositório GitHub. O workflow `.github/workflows/build.yml` gera o APK e o disponibiliza em *Actions → Artifacts*.

Requisitos: minSdk 29 (Android 10), compileSdk 35, AGP 8.7.3, Kotlin 2.0.21, Gradle 8.10.2 (wrapper incluso).

## Como usar
1. Instale o APK e abra o app → tela **Ativação**.
2. Conceda **Sobreposição** (obrigatória) e notificações.
3. Escolha o método:
   - **Shizuku** (recomendado): instale o app Shizuku, inicie-o (Depuração sem fio no Android 11+), volte e toque *Ativar Shizuku*.
   - **Root**: toque *Ativar Root* e aceite o pedido do Magisk/KernelSU.
   - **Sem root**: ative o serviço de acessibilidade (Android 13+: *Info do app → ⋮ → Permitir configurações restritas* primeiro).
4. Conecte teclado e mouse (USB OTG/Bluetooth). Em **Mapeador**, use o perfil modelo Free Fire ou crie o seu; ajuste no **Editor**.
5. *Iniciar mapeamento* (Dashboard/Mapeador/painel/notificação), abra o jogo. Tecla padrão liga/desliga: **F8**.

## O que cada método permite (verificado, nada simulado)
| Recurso | Shizuku | Root | Sem root |
|---|---|---|---|
| Toques multitoque | `IInputManager.injectInputEvent` (uid shell) | idem, daemon root | gestos de acessibilidade (~30 ms de latência) |
| Resolução/DPI (`wm size/density`) | ✅ | ✅ | ❌ (só leitura) |
| FPS (`dumpsys SurfaceFlinger --latency`) | ✅ se o aparelho expõe | ✅ idem | ❌ |
| RAM por app (`dumpsys meminfo`) | ✅ | ✅ | ❌ |
| Limpeza de RAM | ✅ | ✅ | ✅ (`killBackgroundProcesses`) |
| Temperatura | bateria + estado térmico | idem | idem |

## Arquitetura
```
core/        Backends (Shizuku, Root, Acessibilidade), ActivationManager, GestureInjector
privileged/  Código que roda em processo privilegiado: TouchInjector, PrivilegedService (Shizuku UserService), RootServer
input/       MappingEngine (teclas, mouse, WASD, câmera, recuo, polling), DeviceMonitor
data/        Room (perfis + controles), DataStore (configurações)
system/      ScreenManager (resolução), RamManager, Telemetry (temperatura/FPS)
service/     FloatingService (painel + janelas), KeyMapperAccessibilityService
ui/          Tema, componentes, 10 telas, painel flutuante, editor visual
```
- **Mouse:** janela de tela cheia *não tocável* mas focável usa *Pointer Capture* (Android 8+) para receber movimento relativo, botões e roda. Teclado: pelo serviço de acessibilidade (qualquer app em primeiro plano) ou pela mesma janela focada.
- **Câmera:** arrasto virtual numa área configurável; ao sair da área, solta e reinicia no centro. Sensibilidade X/Y, multiplicador, aceleração, suavização e inversão por perfil.
- **Polling rate:** 125/250/500 Hz define o intervalo do loop do app (8/4/2 ms). **Não altera o mouse físico** (o Android não permite) — a tela diz isso.
- **Recuo:** soma um deslizamento linear (X/Y × intensidade) à câmera enquanto um botão marcado como "disparo" está pressionado. Calibrado por você; não lê o jogo.
- **Resolução:** limites rígidos, confirmação com contagem de 15 s e temporizador no shell que restaura mesmo se o app morrer. Emergência: `adb shell wm size reset && adb shell wm density reset`.
- **RAM:** só pede ao Android que encerre processos em segundo plano; nunca sistema, teclado, launcher, acessibilidade, Shizuku, este app, o jogo do perfil nem sua lista de proteção.

## Limitações do Android (importante)
- Sem Shizuku/Root não há resolução, FPS nem consumo por app, e os toques têm mais latência.
- Com o mouse capturado não há cursor; use o painel flutuante com o dedo (ou a tecla F8).
- Sem acessibilidade, a tecla F8 só funciona com o mapeamento já ligado; ligue pelo painel/notificação.
- Alguns jogos reagem à perda de foco da janela; fabricantes (Xiaomi, Samsung, Huawei…) podem exigir "sem restrições de bateria" e permissões extras.
- **Anti-cheat:** jogos como Free Fire podem detectar toques injetados e banir a conta. Use por sua conta e risco, de preferência em conta secundária.
- Android 14+: serviço em primeiro plano do tipo `specialUse` (declarado no manifesto).
