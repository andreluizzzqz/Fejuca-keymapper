package com.keymapperpro.data

import android.content.Context
import android.view.KeyEvent
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "settings")
private val RAM_WHITELIST = androidx.datastore.preferences.core.stringSetPreferencesKey("ram_whitelist")
private val ORIG_SIZE = stringPreferencesKey("orig_size")
private val ORIG_DENSITY = intPreferencesKey("orig_density")

data class Settings(
    val activeProfileId: Long = -1,
    val mode: String = "NO_ROOT",
    val toggleKey: Int = KeyEvent.KEYCODE_F8,
    val showControls: Boolean = true,
    val panelAlpha: Float = 0.9f,
    val panelScale: Float = 1f,
    val panelX: Int = 24,
    val panelY: Int = 160,
    val panelShowRam: Boolean = true,
    val panelShowTemp: Boolean = true,
    val panelShowSens: Boolean = true,
    val panelShowResolution: Boolean = true,
    val rootToken: String = "",
)

object Keys {
    val activeProfile = longPreferencesKey("active_profile")
    val mode = stringPreferencesKey("mode")
    val toggleKey = intPreferencesKey("toggle_key")
    val showControls = booleanPreferencesKey("show_controls")
    val panelAlpha = floatPreferencesKey("panel_alpha")
    val panelScale = floatPreferencesKey("panel_scale")
    val panelX = intPreferencesKey("panel_x")
    val panelY = intPreferencesKey("panel_y")
    val panelShowRam = booleanPreferencesKey("panel_show_ram")
    val panelShowTemp = booleanPreferencesKey("panel_show_temp")
    val panelShowSens = booleanPreferencesKey("panel_show_sens")
    val panelShowResolution = booleanPreferencesKey("panel_show_resolution")
    val rootToken = stringPreferencesKey("root_token")
}

class SettingsStore(private val ctx: Context) {
    val flow: Flow<Settings> = ctx.store.data.map { p ->
        val d = Settings()
        Settings(
            activeProfileId = p[Keys.activeProfile] ?: d.activeProfileId,
            mode = p[Keys.mode] ?: d.mode,
            toggleKey = p[Keys.toggleKey] ?: d.toggleKey,
            showControls = p[Keys.showControls] ?: d.showControls,
            panelAlpha = p[Keys.panelAlpha] ?: d.panelAlpha,
            panelScale = p[Keys.panelScale] ?: d.panelScale,
            panelX = p[Keys.panelX] ?: d.panelX,
            panelY = p[Keys.panelY] ?: d.panelY,
            panelShowRam = p[Keys.panelShowRam] ?: d.panelShowRam,
            panelShowTemp = p[Keys.panelShowTemp] ?: d.panelShowTemp,
            panelShowSens = p[Keys.panelShowSens] ?: d.panelShowSens,
            panelShowResolution = p[Keys.panelShowResolution] ?: d.panelShowResolution,
            rootToken = p[Keys.rootToken] ?: d.rootToken,
        )
    }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        ctx.store.edit { it[key] = value }
    }

    suspend fun settingsOnce(): Settings = flow.first()

    /** Apps que nunca são encerrados pelo otimizador de RAM (escolha do usuário). */
    val ramWhitelist: Flow<Set<String>> = ctx.store.data.map { it[RAM_WHITELIST] ?: emptySet() }

    suspend fun setRamWhitelist(v: Set<String>) {
        ctx.store.edit { it[RAM_WHITELIST] = v }
    }

    /** Estado salvo antes de alterar resolução/DPI (para restaurar com segurança). */
    suspend fun saveOriginalDisplay(size: String, density: Int) {
        ctx.store.edit {
            it[ORIG_SIZE] = size
            it[ORIG_DENSITY] = density
        }
    }

    val originalDisplay: Flow<Pair<String, Int>?> = ctx.store.data.map {
        val s = it[ORIG_SIZE]
        val d = it[ORIG_DENSITY]
        if (s != null && d != null) s to d else null
    }

    suspend fun setPanelPosition(x: Int, y: Int) {
        ctx.store.edit {
            it[Keys.panelX] = x
            it[Keys.panelY] = y
        }
    }

    /** Token aleatório que autentica o app perante o daemon root. Gerado uma única vez. */
    suspend fun ensureRootToken(): String {
        var token = ""
        ctx.store.edit {
            token = it[Keys.rootToken] ?: java.util.UUID.randomUUID().toString().replace("-", "")
            it[Keys.rootToken] = token
        }
        return token
    }
}
