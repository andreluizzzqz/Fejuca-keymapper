package com.keymapperpro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import com.keymapperpro.data.ProfileEntity
import com.keymapperpro.ui.theme.Chip
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.SliderRow
import com.keymapperpro.ui.theme.SwitchRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

/** Mantém o valor do slider local durante o arraste e grava no perfil ao soltar. */
@Composable
private fun PSlider(
    label: String, p: ProfileEntity, get: (ProfileEntity) -> Float,
    set: (ProfileEntity, Float) -> ProfileEntity, range: ClosedFloatingPointRange<Float>,
    format: (Float) -> String = { "%.2f".format(it) },
) {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    var v by remember(p.id, get(p)) { mutableStateOf(get(p)) }
    SliderRow(label, v, { v = it }, range, format) {
        scope.launch { c.engine.updateProfile { set(it, v) } }
    }
}

@Composable
fun SensitivityScreen() {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    val profile by c.engine.profile.collectAsState()
    val devices by c.devices.devices.collectAsState()

    ScreenColumn("Sensibilidade", "Valores salvos por perfil. Aplicados em tempo real ao movimento do mouse.") {
        val p = profile
        if (p == null) {
            Notice("Selecione um perfil na tela Mapeador.", Tone.WARN)
            return@ScreenColumn
        }
        Text("Perfil: ${p.name}", color = Gx.Text, style = MaterialTheme.typography.titleMedium)

        GCard(title = "Movimento") {
            PSlider("Sensibilidade X", p, { it.sensX }, { q, v -> q.copy(sensX = v) }, 0.1f..5f)
            PSlider("Sensibilidade Y", p, { it.sensY }, { q, v -> q.copy(sensY = v) }, 0.1f..5f)
            PSlider("Multiplicador de velocidade", p, { it.speedMul }, { q, v -> q.copy(speedMul = v) }, 0.25f..4f)
            PSlider("Aceleração do mouse", p, { it.accel }, { q, v -> q.copy(accel = v) }, 0f..2f)
            Text(
                "Aceleração: movimentos rápidos ganham até +${(p.accel * 200).toInt()}% de velocidade; 0 = linear.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
            PSlider("Suavização", p, { it.smoothing }, { q, v -> q.copy(smoothing = v) }, 0f..0.9f) { "${(it * 100).toInt()}%" }
            Text("Suavização alta reduz tremor, mas adiciona atraso ao movimento.", color = Gx.TextDim, style = MaterialTheme.typography.bodySmall)
        }

        GCard(title = "Eixos") {
            SwitchRow("Inverter eixo X", p.invertX, { v -> scope.launch { c.engine.updateProfile { it.copy(invertX = v) } } })
            SwitchRow("Inverter eixo Y", p.invertY, { v -> scope.launch { c.engine.updateProfile { it.copy(invertY = v) } } })
        }

        GCard(title = "Frequência de atualização (Polling Rate)") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(125, 250, 500).forEach { hz ->
                    Chip("$hz Hz", p.pollingHz == hz) { scope.launch { c.engine.updateProfile { it.copy(pollingHz = hz) } } }
                }
            }
            Text("Selecionado: ${p.pollingHz} Hz (intervalo de ${1000 / p.pollingHz} ms)", color = Gx.Text, style = MaterialTheme.typography.bodyMedium)
            Notice(
                "Compatibilidade: o Android não permite alterar o polling rate físico do mouse — isso é feito pelo firmware/driver do " +
                    "próprio mouse. Este valor é apenas uma preferência de processamento do app: define com que frequência os movimentos " +
                    "acumulados são enviados como toque. No modo sem root, o envio por gestos é limitado a ~30 ms, então 250/500 Hz não trazem ganho.",
                Tone.WARN,
            )
            val mice = devices.filter { it.isMouse }
            Text(
                if (mice.isEmpty()) "Nenhum mouse conectado agora." else "Mouse: ${mice.first().name} (taxa física não informada pelo Android)",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
