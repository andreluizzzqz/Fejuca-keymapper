package com.keymapperpro.system

import android.app.Application
import android.content.Context
import android.graphics.Point
import android.view.WindowManager
import com.keymapperpro.core.ActivationManager
import com.keymapperpro.data.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToInt

data class DisplayState(
    val curW: Int = 0, val curH: Int = 0, val curDpi: Int = 0,
    val physW: Int = 0, val physH: Int = 0, val physDpi: Int = 0,
    val overridden: Boolean = false,
)

data class ResPreset(val label: String, val w: Int, val h: Int, val dpi: Int)

data class Validation(val errors: List<String>, val warnings: List<String>) {
    val ok get() = errors.isEmpty()
}

/**
 * Resolução e DPI via `wm size` / `wm density` (exige Shizuku ou Root; o Android não permite
 * isso a apps comuns). Segurança: limites rígidos + confirmação com reversão automática, e um
 * "interruptor de homem morto" no próprio shell que restaura mesmo se o app for encerrado.
 */
class ScreenManager(
    private val app: Application,
    private val scope: CoroutineScope,
    private val activation: ActivationManager,
    private val settings: SettingsStore,
) {
    companion object {
        const val CONFIRM_SECONDS = 15
        const val MIN_SIDE = 480
        const val MIN_DPI = 120
        const val MAX_DPI = 800
        const val MIN_SW_DP = 320
    }

    val state = MutableStateFlow(DisplayState())
    val countdown = MutableStateFlow(0) // >0 = aguardando confirmação
    val message = MutableStateFlow<String?>(null)
    val busy = MutableStateFlow(false)

    private var countdownJob: Job? = null
    private var guardPid: String? = null

    val canApply get() = activation.backend.value?.canShell == true

    /** Lê o estado atual. Sem privilégio, usa as métricas reais da tela (somente leitura). */
    suspend fun refresh() {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val p = Point()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealSize(p)
        val dpi = app.resources.displayMetrics.densityDpi
        var s = DisplayState(p.x, p.y, dpi)
        val b = activation.backend.value
        if (b != null && b.canShell) {
            val size = b.exec("wm size").out
            val den = b.exec("wm density").out
            val phys = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(size)
            val over = Regex("Override size:\\s*(\\d+)x(\\d+)").find(size)
            val pd = Regex("Physical density:\\s*(\\d+)").find(den)
            val od = Regex("Override density:\\s*(\\d+)").find(den)
            if (phys != null) {
                val pw = phys.groupValues[1].toInt()
                val ph = phys.groupValues[2].toInt()
                val cw = over?.groupValues?.get(1)?.toInt() ?: pw
                val ch = over?.groupValues?.get(2)?.toInt() ?: ph
                val physDpi = pd?.groupValues?.get(1)?.toInt() ?: dpi
                val curDpi = od?.groupValues?.get(1)?.toInt() ?: physDpi
                s = DisplayState(cw, ch, curDpi, pw, ph, physDpi, over != null || od != null)
            }
        } else {
            s = s.copy(physW = 0, physH = 0, physDpi = 0)
        }
        state.value = s
    }

    fun presets(): List<ResPreset> {
        val s = state.value
        if (s.physW == 0) return emptyList()
        val long = maxOf(s.physW, s.physH)
        val short = minOf(s.physW, s.physH)
        val portrait = s.physH >= s.physW
        return listOf(100, 90, 80, 75, 67, 60, 50).map { pct ->
            val l = even(long * pct / 100f)
            val sh = even(short * pct / 100f)
            val dpi = (s.physDpi * pct / 100f).roundToInt()
            val w = if (portrait) sh else l
            val h = if (portrait) l else sh
            ResPreset(if (pct == 100) "Nativa (${w}x$h)" else "$pct% (${w}x$h)", w, h, dpi)
        }.filter { minOf(it.w, it.h) >= MIN_SIDE }
    }

    private fun even(v: Float) = (v / 2f).roundToInt() * 2

    fun validate(w: Int, h: Int, dpi: Int): Validation {
        val s = state.value
        val err = mutableListOf<String>()
        val warn = mutableListOf<String>()
        if (s.physW == 0) err += "Resolução física desconhecida. Conecte Shizuku ou Root."
        if (minOf(w, h) < MIN_SIDE) err += "Lado menor abaixo de $MIN_SIDE px: a interface ficaria inutilizável."
        if (dpi < MIN_DPI || dpi > MAX_DPI) err += "DPI deve ficar entre $MIN_DPI e $MAX_DPI."
        if (s.physW > 0) {
            val longP = maxOf(s.physW, s.physH)
            val shortP = minOf(s.physW, s.physH)
            if (maxOf(w, h) > longP || minOf(w, h) > shortP) err += "Maior que a resolução física (${s.physW}x${s.physH})."
            val ratioP = longP.toFloat() / shortP
            val ratio = maxOf(w, h).toFloat() / minOf(w, h)
            if (ratio < 1.0f || ratio > 2.6f) err += "Proporção ${"%.2f".format(ratio)}:1 fora do limite seguro."
            else if (kotlin.math.abs(ratio - ratioP) > 0.08f) warn += "Proporção diferente da tela física (${"%.2f".format(ratioP)}:1): haverá distorção/barras."
            val portraitP = s.physH >= s.physW
            if ((h >= w) != portraitP) err += "Orientação invertida em relação à tela física."
        }
        val swdp = minOf(w, h) * 160f / dpi
        if (swdp < MIN_SW_DP) err += "Largura mínima de ${swdp.roundToInt()} dp (< $MIN_SW_DP dp): o sistema não suporta."
        else if (swdp < 360) warn += "Largura mínima de ${swdp.roundToInt()} dp: alguns apps podem quebrar o layout."
        if (dpi < 200) warn += "DPI baixo deixa textos e botões minúsculos."
        if (w % 2 != 0 || h % 2 != 0) warn += "Use valores pares; alguns aparelhos recusam valores ímpares."
        warn += "Alguns fabricantes (Samsung, Xiaomi, etc.) ignoram ou limitam `wm size` com tela de alta taxa; o Free Fire não muda a própria resolução interna por isso."
        return Validation(err, warn)
    }

    /** Aplica e inicia a contagem de confirmação. Sem confirmação, volta ao estado anterior. */
    suspend fun apply(w: Int, h: Int, dpi: Int): Boolean {
        val b = activation.backend.value
        if (b == null || !b.canShell) {
            message.value = "Alterar resolução exige Shizuku ou Root. O Android bloqueia isso para apps comuns."
            return false
        }
        val v = validate(w, h, dpi)
        if (!v.ok) {
            message.value = v.errors.first()
            return false
        }
        busy.value = true
        try {
            refresh()
            val s = state.value
            if (settings.originalDisplay.first() == null || !s.overridden) {
                settings.saveOriginalDisplay("${s.physW}x${s.physH}", s.physDpi)
            }
            // Interruptor de segurança: se ninguém confirmar, o próprio shell restaura.
            val guard = b.exec(
                "nohup sh -c 'sleep ${CONFIRM_SECONDS + 5}; wm size reset; wm density reset' >/dev/null 2>&1 & echo \$!"
            )
            guardPid = guard.out.trim().lines().lastOrNull()?.takeIf { it.all(Char::isDigit) }

            val r1 = b.exec("wm size ${w}x$h")
            val r2 = b.exec("wm density $dpi")
            if (!r1.ok || !r2.ok) {
                message.value = "Falha ao aplicar: ${(if (!r1.ok) r1 else r2).out.take(160)}"
                restoreInternal()
                return false
            }
            refresh()
            message.value = "Aplicado. Confirme em $CONFIRM_SECONDS s ou a configuração anterior volta sozinha."
            startCountdown()
            return true
        } finally {
            busy.value = false
        }
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = scope.launch {
            for (i in CONFIRM_SECONDS downTo 1) {
                countdown.value = i
                delay(1000)
            }
            countdown.value = 0
            restoreInternal()
            message.value = "Sem confirmação: configuração original restaurada."
        }
    }

    /** Usuário confirmou: cancela a reversão automática. */
    suspend fun confirm() {
        countdownJob?.cancel()
        countdown.value = 0
        killGuard()
        message.value = "Nova resolução mantida."
    }

    suspend fun restore() {
        countdownJob?.cancel()
        countdown.value = 0
        restoreInternal()
        message.value = "Configuração original restaurada."
    }

    private suspend fun killGuard() {
        val pid = guardPid ?: return
        activation.backend.value?.exec("kill $pid")
        guardPid = null
    }

    private suspend fun restoreInternal() {
        val b = activation.backend.value
        if (b != null && b.canShell) {
            b.exec("wm size reset")
            b.exec("wm density reset")
        }
        killGuard()
        refresh()
    }

    fun aspectOf(w: Int, h: Int) = if (h == 0) 0f else min(w, h).toFloat() / maxOf(w, h)
}
