package com.keymapperpro.ui.screens

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.keymapperpro.data.ControlType
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.SliderRow
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.SwitchRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

@Composable
fun RecoilScreen() {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    val profile by c.engine.profile.collectAsState()
    val controls by c.engine.controls.collectAsState()
    val holding by c.engine.recoilHolding.collectAsState()

    ScreenColumn(
        "Controle de recuo",
        "Compensação de movimento configurável, por perfil (e portanto por jogo)."
    ) {
        val p = profile
        if (p == null) {
            Notice("Selecione um perfil na tela Mapeador.", Tone.WARN)
            return@ScreenColumn
        }
        val hasCam = controls.any { it.type == ControlType.CAMERA }
        val hasFire = controls.any { it.isFire }

        Notice(
            "Como funciona: enquanto um botão marcado como \"disparo\" está pressionado, o app soma um deslizamento constante " +
                "(horizontal/vertical × intensidade) ao movimento da câmera. É uma compensação linear que VOCÊ calibra; " +
                "o app não lê o jogo nem sabe o padrão de recuo de cada arma, então não existe controle universal. " +
                "Jogos com anti-cheat podem detectar entrada automatizada e punir a conta.",
            Tone.WARN,
        )

        GCard(title = "Perfil: ${p.name}") {
            SwitchRow("Ativar compensação de recuo", p.recoilEnabled, { v -> scope.launch { c.engine.updateProfile { it.copy(recoilEnabled = v) } } },
                "Também pode ser ligada pelo painel flutuante.")
            var x by remember(p.id, p.recoilX) { mutableStateOf(p.recoilX) }
            var y by remember(p.id, p.recoilY) { mutableStateOf(p.recoilY) }
            var k by remember(p.id, p.recoilIntensity) { mutableStateOf(p.recoilIntensity) }
            SliderRow("Ajuste horizontal (px/s)", x, { x = it }, -300f..300f, { "${it.toInt()}" }) {
                scope.launch { c.engine.updateProfile { q -> q.copy(recoilX = x) } }
            }
            SliderRow("Ajuste vertical (px/s, + = para baixo)", y, { y = it }, -300f..300f, { "${it.toInt()}" }) {
                scope.launch { c.engine.updateProfile { q -> q.copy(recoilY = y) } }
            }
            SliderRow("Intensidade", k, { k = it }, 0f..3f, { "%.2fx".format(it) }) {
                scope.launch { c.engine.updateProfile { q -> q.copy(recoilIntensity = k) } }
            }
            Text(
                "Resultado: ${"%.0f".format(x * k)} px/s horizontal, ${"%.0f".format(y * k)} px/s vertical.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
            Row {
                GOutlined("Zerar", {
                    scope.launch { c.engine.updateProfile { it.copy(recoilX = 0f, recoilY = 0f, recoilIntensity = 1f) } }
                }, Modifier.fillMaxWidth())
            }
        }

        GCard(title = "Requisitos do perfil") {
            StatusRow("Controle de câmera", if (hasCam) "Presente" else "Ausente", if (hasCam) Tone.OK else Tone.ERR)
            StatusRow("Botão de disparo", if (hasFire) "Marcado" else "Nenhum marcado", if (hasFire) Tone.OK else Tone.ERR)
            StatusRow("Compensação agora", if (holding) "Aplicando" else "Em espera", if (holding) Tone.OK else Tone.OFF)
            if (!hasCam || !hasFire) {
                Notice("Sem esses dois controles a compensação não age. Marque \"Botão de disparo\" no editor de controles e mantenha a área da câmera.", Tone.ERR)
            }
        }
    }
}
