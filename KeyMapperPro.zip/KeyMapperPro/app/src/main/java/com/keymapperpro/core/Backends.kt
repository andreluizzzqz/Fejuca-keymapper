package com.keymapperpro.core

import android.content.Context
import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.os.Process
import com.keymapperpro.IPrivilegedService
import com.keymapperpro.privileged.RootServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

enum class ActivationMode { SHIZUKU, ROOT, NO_ROOT }

data class ExecResult(val code: Int, val out: String) {
    val ok get() = code == 0
}

fun parseExec(raw: String): ExecResult {
    val nl = raw.indexOf('\n')
    val code = (if (nl < 0) raw else raw.substring(0, nl)).trim().toIntOrNull() ?: -1
    return ExecResult(code, if (nl < 0) "" else raw.substring(nl + 1))
}

/** Caminho de envio de toques e (quando houver privilégio) de comandos de shell. */
interface InputBackend {
    val name: String
    val canShell: Boolean
    fun touch(action: Int, pointerId: Int, x: Float, y: Float)
    fun releaseAll()
    suspend fun exec(cmd: String): ExecResult
}

class ShizukuBackend(val svc: IPrivilegedService) : InputBackend {
    override val name = "Shizuku"
    override val canShell = true
    override fun touch(action: Int, pointerId: Int, x: Float, y: Float) {
        try {
            svc.touch(action, pointerId, x, y)
        } catch (_: Exception) {
        }
    }

    override fun releaseAll() {
        try {
            svc.releaseAll()
        } catch (_: Exception) {
        }
    }

    override suspend fun exec(cmd: String): ExecResult = withContext(Dispatchers.IO) {
        try {
            parseExec(svc.exec(cmd))
        } catch (e: Exception) {
            ExecResult(-1, e.message ?: "falha ao executar")
        }
    }
}

class RootBackend(private val client: RootClient) : InputBackend {
    override val name = "Root"
    override val canShell = true
    override fun touch(action: Int, pointerId: Int, x: Float, y: Float) = client.touch(action, pointerId, x, y)
    override fun releaseAll() = client.releaseAll()
    override suspend fun exec(cmd: String): ExecResult = withContext(Dispatchers.IO) { client.exec(cmd) }
}

class AccessibilityBackend(private val inj: GestureInjector) : InputBackend {
    override val name = "Sem root (Acessibilidade)"
    override val canShell = false
    override fun touch(action: Int, pointerId: Int, x: Float, y: Float) = inj.touch(action, pointerId, x, y)
    override fun releaseAll() = inj.releaseAll()
    override suspend fun exec(cmd: String): ExecResult =
        ExecResult(-1, "Comandos de sistema exigem Shizuku ou Root.")
}

/** Cliente do daemon root (RootServer). */
class RootClient(private val ctx: Context, private val token: String) {
    private var socket: LocalSocket? = null
    private var out: DataOutputStream? = null
    private var inp: DataInputStream? = null
    private val lock = Any()
    private val io = Executors.newSingleThreadExecutor()

    val connected get() = socket != null

    fun connect(): Boolean = synchronized(lock) {
        close()
        try {
            val s = LocalSocket()
            s.connect(
                LocalSocketAddress(RootServer.socketName(Process.myUid()), LocalSocketAddress.Namespace.ABSTRACT)
            )
            val o = DataOutputStream(BufferedOutputStream(s.outputStream))
            val i = DataInputStream(s.inputStream.buffered())
            o.writeUTF(token)
            o.flush()
            if (i.readInt() != RootServer.PROTOCOL) {
                s.close()
                return false
            }
            socket = s
            out = o
            inp = i
            true
        } catch (e: Exception) {
            close()
            false
        }
    }

    /** Sobe o daemon via `su`. Mostra o pedido do gerenciador de root na primeira vez. */
    suspend fun startServerAndConnect(): Boolean = withContext(Dispatchers.IO) {
        if (connect()) return@withContext true
        val apk = ctx.applicationInfo.sourceDir
        val script = "CLASSPATH='$apk' nohup app_process /system/bin --nice-name=keymapperpro_root " +
            "com.keymapperpro.privileged.RootServer '$token' ${Process.myUid()} >/dev/null 2>&1 &"
        try {
            val p = ProcessBuilder("su", "-c", script).redirectErrorStream(true).start()
            p.waitFor(20, TimeUnit.SECONDS)
        } catch (e: Exception) {
            return@withContext false
        }
        repeat(12) {
            delay(300)
            if (connect()) return@withContext true
        }
        false
    }

    fun touch(action: Int, id: Int, x: Float, y: Float) {
        io.execute {
            synchronized(lock) {
                try {
                    val o = out ?: return@execute
                    o.writeByte(1)
                    o.writeInt(action)
                    o.writeInt(id)
                    o.writeFloat(x)
                    o.writeFloat(y)
                    o.flush()
                } catch (e: Exception) {
                    close()
                }
            }
        }
    }

    fun releaseAll() {
        io.execute {
            synchronized(lock) {
                try {
                    val o = out ?: return@execute
                    o.writeByte(2)
                    o.flush()
                } catch (e: Exception) {
                    close()
                }
            }
        }
    }

    fun exec(cmd: String): ExecResult = synchronized(lock) {
        try {
            val o = out ?: return ExecResult(-1, "root não conectado")
            val i = inp ?: return ExecResult(-1, "root não conectado")
            o.writeByte(3)
            o.writeUTF(cmd)
            o.flush()
            parseExec(i.readUTF())
        } catch (e: Exception) {
            close()
            ExecResult(-1, e.message ?: "falha")
        }
    }

    fun stopServer() = synchronized(lock) {
        try {
            out?.writeByte(0)
            out?.flush()
        } catch (_: Exception) {
        }
        close()
    }

    fun close() {
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        socket = null
        out = null
        inp = null
    }
}
