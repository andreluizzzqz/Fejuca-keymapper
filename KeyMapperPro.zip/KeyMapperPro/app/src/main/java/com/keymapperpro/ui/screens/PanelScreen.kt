package com.keymapperpro.ui.screens

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.keymapperpro.data.Keys
import com.keymapperpro.service.FloatingService
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.SliderRow
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.SwitchRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

@Composable
fun PanelScreen() {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by c.settings.flow.collectAsState(initial = com.keymapperpro.data.Settings())
    val running by FloatingService.running.collectAsState()
    val act by c.activation.status.collectAsState()
    var error by remember { mutableStateOf<String?>(null) }

    ScreenColumn("Painel flutuante", "Pílula arrastável para usar durante o jogo.") {
        GCard(title = "Estado", accent = running) {
            StatusRow("Painel", if (running) "Aberto" else "Fechado", if (running) Tone.OK else Tone.OFF)
            StatusRow("Permissão de sobreposição", if (act.overlay) "Concedida" else "Pendente", if (act.overlay) Tone.OK else Tone.ERR)
            error?.let { Notice(it, Tone.ERR) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (running) GButton("Fechar painel", { FloatingService.stop(ctx) }, Modifier.weight(1f))
                else GButton("Abrir painel", {
                    if (!android.provider.Settings.canDrawOverlays(ctx)) error = "Conceda a permissão de sobreposição na tela Ativação."
                    else { error = null; FloatingService.start(ctx) }
                }, Modifier.weight(1f))
                if (!act.overlay) GOutlined("Conceder", { openOverlaySettings(ctx) }, Modifier.weight(1f))
            }
        }

        GCard(title = "Aparência") {
            SliderRow("Transparência", s.panelAlpha, { v -> scope.launch { c.settings.set(Keys.panelAlpha, v) } }, 0.3f..1f, { "${(it * 100).toInt()}%" })
            SliderRow("Tamanho", s.panelScale, { v -> scope.launch { c.settings.set(Keys.panelScale, v) } }, 0.7f..1.3f, { "${(it * 100).toInt()}%" })
            GOutlined("Restaurar posição", {
                scope.launch { c.settings.setPanelPosition(24, 160) }
            }, Modifier.fillMaxWidth())
            Text("A posição é salva ao soltar o painel. Reabra o painel para aplicar a posição restaurada.", color = Gx.TextDim, style = MaterialTheme.typography.bodySmall)
        }

        GCard(title = "Informações exibidas") {
            SwitchRow("RAM", s.panelShowRam, { v -> scope.launch { c.settings.set(Keys.panelShowRam, v) } })
            SwitchRow("Temperatura", s.panelShowTemp, { v -> scope.launch { c.settings.set(Keys.panelShowTemp, v) } })
        }

        GCard(title = "O que o painel faz") {
            Text(
                "• Liga/desliga o mapeamento e troca de perfil.\n" +
                    "• Mostra o teclado e o mouse conectados.\n" +
                    "• Ajusta sensibilidade X/Y e liga a compensação de recuo.\n" +
                    "• Aplica presets de resolução (Shizuku/Root) com confirmação.\n" +
                    "• Mostra RAM e limpa processos em segundo plano com segurança.\n" +
                    "• FPS: só com Shizuku/Root e quando o aparelho expõe os dados; senão aparece o motivo.\n" +
                    "• Temperatura: sensor da bateria + estado térmico do sistema.\n\n" +
                    "Com o mapeamento ligado o mouse fica capturado (sem cursor): use o painel com o dedo. " +
                    "A janela do painel não rouba o foco do teclado.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
