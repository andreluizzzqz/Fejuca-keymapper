package com.keymapperpro.system

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.Intent
import com.keymapperpro.core.ActivationManager
import com.keymapperpro.data.SettingsStore
import com.keymapperpro.service.KeyMapperAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class RamInfo(val totalMb: Long = 0, val availMb: Long = 0, val lowMemory: Boolean = false) {
    val usedMb get() = (totalMb - availMb).coerceAtLeast(0)
    val usedPct get() = if (totalMb == 0L) 0f else usedMb * 100f / totalMb
}

data class AppMem(
    val pkg: String,
    val label: String,
    val pssMb: Float,
    val pid: Int,
    val protectedReason: String?,
    val foreground: Boolean,
)

data class OptimizeResult(val killed: Int, val freedMb: Long, val note: String)

/**
 * Leitura real de memória (ActivityManager + /proc/meminfo) e limpeza real: apenas
 * ActivityManager.killBackgroundProcesses (processos em segundo plano, que o Android recria sob
 * demanda). Nunca encerra apps protegidos, sistema, teclado, launcher, serviços de acessibilidade
 * nem a lista do usuário. Não promete FPS: liberar RAM só ajuda se o aparelho estava sem memória.
 */
class RamManager(
    private val app: Application,
    private val scope: CoroutineScope,
    private val activation: ActivationManager,
    private val settings: SettingsStore,
) {
    val info = MutableStateFlow(RamInfo())
    val history = MutableStateFlow<List<Float>>(emptyList())
    val apps = MutableStateFlow<List<AppMem>>(emptyList())
    val appsNote = MutableStateFlow<String?>(null)

    /** Pacote do jogo do perfil ativo: nunca é encerrado. */
    @Volatile var gamePackage: String? = null

    private val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private var watchers = 0
    private var job: Job? = null

    /** Amostragem só roda enquanto houver quem observe (tela de RAM, painel, dashboard). */
    fun acquire(withApps: Boolean = false) {
        watchers++
        if (job?.isActive == true) return
        job = scope.launch(Dispatchers.IO) {
            var n = 0
            while (isActive) {
                sample()
                if (withApps && n % 5 == 0) loadApps()
                n++
                delay(2000)
            }
        }
    }

    fun release() {
        watchers = (watchers - 1).coerceAtLeast(0)
        if (watchers == 0) {
            job?.cancel()
            job = null
        }
    }

    fun sample() {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        var total = mi.totalMem / MB
        var avail = mi.availMem / MB
        if (total <= 0) {
            runCatching {
                java.io.File("/proc/meminfo").forEachLine {
                    if (it.startsWith("MemTotal")) total = it.filter(Char::isDigit).toLong() / 1024
                    if (it.startsWith("MemAvailable")) avail = it.filter(Char::isDigit).toLong() / 1024
                }
            }
        }
        val r = RamInfo(total, avail, mi.lowMemory)
        info.value = r
        history.value = (history.value + r.usedPct).takeLast(150) // ~5 min
    }

    // ---------- Consumo por aplicativo (somente com Shizuku/Root) ----------

    private fun launcherPackages(): Map<String, String> {
        val pm = app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).associate {
            it.activityInfo.packageName to it.loadLabel(pm).toString()
        }
    }

    private fun protectedSet(): Map<String, String> {
        val m = HashMap<String, String>()
        m[app.packageName] = "Este app"
        val pm = app.packageManager
        pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName?.let { m[it] = "Tela inicial" }
        runCatching {
            android.provider.Settings.Secure.getString(app.contentResolver, "default_input_method")
                ?.substringBefore('/')?.let { m[it] = "Teclado" }
        }
        runCatching {
            android.provider.Settings.Secure.getString(app.contentResolver, "enabled_accessibility_services")
                ?.split(':')?.forEach { s -> s.substringBefore('/').takeIf { it.isNotBlank() }?.let { m[it] = "Acessibilidade" } }
        }
        m["moe.shizuku.privileged.api"] = "Shizuku"
        KeyMapperAccessibilityService.foregroundPackage?.let { m[it] = "Em primeiro plano" }
        gamePackage?.let { m[it] = "Jogo do perfil" }
        listOf("com.android.systemui", "android", "com.android.phone", "com.android.providers.media").forEach {
            m[it] = "Sistema"
        }
        return m
    }

    suspend fun loadApps() {
        val b = activation.backend.value
        if (b == null || !b.canShell) {
            appsNote.value = "Consumo por app exige Shizuku ou Root (o Android oculta a memória de outros apps)."
            apps.value = emptyList()
            return
        }
        val out = b.exec("dumpsys meminfo")
        if (!out.ok || out.out.isBlank()) {
            appsNote.value = "dumpsys meminfo indisponível neste aparelho."
            return
        }
        val launcher = launcherPackages()
        val prot = protectedSet()
        val fg = KeyMapperAccessibilityService.foregroundPackage
        val list = ArrayList<AppMem>()
        var inSection = false
        // Linhas: "    123,456K: com.pacote (pid 1234 / activities)"
        val rx = Regex("^\\s*([\\d.,]+)K:\\s+(\\S+)\\s+\\(pid\\s+(\\d+)")
        for (line in out.out.lineSequence()) {
            if (line.startsWith("Total PSS by process")) { inSection = true; continue }
            if (inSection && line.isBlank()) break
            if (!inSection) continue
            val m = rx.find(line) ?: continue
            val kb = m.groupValues[1].replace(",", "").replace(".", "").toLongOrNull() ?: continue
            val proc = m.groupValues[2]
            val pkg = proc.substringBefore(':')
            if (pkg !in launcher && pkg !in prot) continue // só apps visíveis ao usuário
            list += AppMem(
                pkg, launcher[pkg] ?: pkg, kb / 1024f, m.groupValues[3].toInt(),
                prot[pkg], pkg == fg,
            )
        }
        apps.value = list.sortedByDescending { it.pssMb }
        appsNote.value = if (list.isEmpty()) "Nenhum app encontrado na saída do dumpsys." else null
    }

    // ---------- Otimização segura ----------

    /**
     * @param only se informado, limita aos pacotes escolhidos. Caso contrário usa os apps em
     * segundo plano conhecidos (privilegiado) ou os apps de launcher (sem privilégio),
     * sempre excluindo protegidos + lista do usuário.
     */
    suspend fun optimize(only: Set<String>? = null): OptimizeResult = withContext(Dispatchers.IO) {
        sample()
        val before = info.value.availMb
        val prot = protectedSet().keys
        val white = settings.ramWhitelist.first()
        val b = activation.backend.value
        val candidates: Set<String> = only ?: if (b?.canShell == true) {
            loadApps()
            apps.value.filter { !it.foreground }.map { it.pkg }.toSet()
        } else launcherPackages().keys
        val targets = candidates.filter { it !in prot && it !in white }
        for (p in targets) {
            try {
                am.killBackgroundProcesses(p)
            } catch (_: SecurityException) {
            }
        }
        delay(1200)
        sample()
        val freed = (info.value.availMb - before).coerceAtLeast(0)
        OptimizeResult(
            targets.size, freed,
            "Foram solicitados o encerramento de processos em segundo plano de ${targets.size} app(s). " +
                "O Android recria o que for necessário; o ganho é temporário e não aumenta FPS por si só."
        )
    }

    companion object {
        private const val MB = 1024L * 1024L
    }
}
