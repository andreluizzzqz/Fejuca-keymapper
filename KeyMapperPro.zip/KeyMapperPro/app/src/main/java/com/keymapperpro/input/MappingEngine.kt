package com.keymapperpro.input

import android.app.Application
import android.content.Context
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import com.keymapperpro.core.ActivationManager
import com.keymapperpro.core.InputBackend
import com.keymapperpro.data.ControlEntity
import com.keymapperpro.data.ControlType
import com.keymapperpro.data.MouseBtn
import com.keymapperpro.data.ProfileEntity
import com.keymapperpro.data.ProfileRepository
import com.keymapperpro.data.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Converte entrada de teclado/mouse em toques. Todas as chamadas chegam na thread principal
 * (AccessibilityService, janela de captura do mouse). O loop de "tick" roda no Handler principal
 * na frequência escolhida (125/250/500 Hz) e só enquanto houver movimento ou recuo pendente.
 */
class MappingEngine(
    private val app: Application,
    scope: CoroutineScope,
    private val repo: ProfileRepository,
    private val settings: SettingsStore,
    private val activation: ActivationManager,
) {
    companion object {
        const val ID_JOY = 0
        const val ID_CAM = 1
        const val ID_FIRST_BTN = 2
        const val CAM_HOLD_RESET_PX = 0.8f // fração do raio da área da câmera antes de reiniciar o arrasto
    }

    val enabled = MutableStateFlow(false)
    val lastError = MutableStateFlow<String?>(null)
    val recoilHolding = MutableStateFlow(false)

    @OptIn(ExperimentalCoroutinesApi::class)
    val profile: StateFlow<ProfileEntity?> = settings.flow.map { it.activeProfileId }.distinctUntilChanged()
        .flatMapLatest { if (it < 0) flowOf(null) else repo.profile(it) }
        .stateIn(scope, SharingStarted.Eagerly, null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val controls: StateFlow<List<ControlEntity>> = settings.flow.map { it.activeProfileId }.distinctUntilChanged()
        .flatMapLatest { if (it < 0) flowOf(emptyList()) else repo.controls(it) }
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    val toggleKey: StateFlow<Int> = settings.flow.map { it.toggleKey }.distinctUntilChanged()
        .stateIn(scope, SharingStarted.Eagerly, KeyEvent.KEYCODE_F8)

    private val handler = Handler(Looper.getMainLooper())
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    // estado de entrada
    private val keysDown = HashSet<Int>()
    private var mouseButtons = 0
    private val activeButtonControls = HashMap<Long, Int>() // controlId -> pointerId
    private var joyActive = false
    private var joyCx = 0f
    private var joyCy = 0f
    private var camActive = false
    private var camX = 0f
    private var camY = 0f
    private var camCx = 0f
    private var camCy = 0f
    private var pendDx = 0f
    private var pendDy = 0f
    private var smDx = 0f
    private var smDy = 0f
    private var lastTick = 0L
    private var ticking = false

    private val backend: InputBackend? get() = activation.backend.value

    private fun screen(): Point {
        val p = Point()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    // ---------------- Liga / desliga ----------------

    fun setEnabled(on: Boolean): Boolean {
        if (on == enabled.value) return true
        if (on) {
            val issue = activation.readinessIssue()
            if (issue != null) {
                lastError.value = issue
                return false
            }
            if (controls.value.isEmpty()) {
                lastError.value = "O perfil ativo não tem controles. Crie ao menos um no editor."
                return false
            }
            lastError.value = null
            enabled.value = true
        } else {
            releaseEverything()
            enabled.value = false
        }
        return true
    }

    fun toggle() = setEnabled(!enabled.value)

    private fun releaseEverything() {
        handler.removeCallbacks(tick)
        ticking = false
        keysDown.clear()
        mouseButtons = 0
        activeButtonControls.clear()
        joyActive = false
        camActive = false
        pendDx = 0f; pendDy = 0f; smDx = 0f; smDy = 0f
        recoilHolding.value = false
        backend?.releaseAll()
    }

    // ---------------- Teclado ----------------

    /** @return true se o evento foi consumido pelo mapeamento. */
    fun onKey(e: KeyEvent): Boolean {
        if (e.keyCode == toggleKey.value) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) toggle()
            return true
        }
        if (!enabled.value) return false
        val list = controls.value
        var consumed = false
        val down = e.action == KeyEvent.ACTION_DOWN
        for (c in list) {
            when (c.type) {
                ControlType.JOYSTICK -> if (e.keyCode in intArrayOf(c.keyUp, c.keyDown, c.keyLeft, c.keyRight)) {
                    consumed = true
                    if (down) keysDown.add(e.keyCode) else keysDown.remove(e.keyCode)
                    updateJoystick(c)
                }
                ControlType.BUTTON -> if (c.keyCode != 0 && c.keyCode == e.keyCode) {
                    consumed = true
                    if (e.repeatCount == 0) setButton(c, down)
                }
            }
        }
        return consumed
    }

    private fun updateJoystick(c: ControlEntity) {
        val s = screen()
        val cx = c.x * s.x
        val cy = c.y * s.y
        val radius = c.size * min(s.x, s.y) / 2f
        var dx = 0f
        var dy = 0f
        if (c.keyLeft in keysDown) dx -= 1f
        if (c.keyRight in keysDown) dx += 1f
        if (c.keyUp in keysDown) dy -= 1f
        if (c.keyDown in keysDown) dy += 1f
        val b = backend ?: return
        if (dx == 0f && dy == 0f) {
            if (joyActive) {
                b.touch(MotionEvent.ACTION_UP, ID_JOY, joyCx, joyCy)
                joyActive = false
            }
            return
        }
        val len = hypot(dx, dy)
        val tx = cx + dx / len * radius * 0.9f
        val ty = cy + dy / len * radius * 0.9f
        if (!joyActive) {
            b.touch(MotionEvent.ACTION_DOWN, ID_JOY, cx, cy)
            joyActive = true
            joyCx = cx; joyCy = cy
        }
        b.touch(MotionEvent.ACTION_MOVE, ID_JOY, tx, ty)
        joyCx = tx; joyCy = ty
    }

    // ---------------- Botões / mouse ----------------

    private fun pointerFor(c: ControlEntity): Int {
        val idx = controls.value.indexOfFirst { it.id == c.id }.coerceAtLeast(0)
        return (ID_FIRST_BTN + idx).coerceAtMost(30)
    }

    private fun setButton(c: ControlEntity, down: Boolean) {
        val b = backend ?: return
        val s = screen()
        val x = c.x * s.x
        val y = c.y * s.y
        val id = pointerFor(c)
        if (down) {
            if (activeButtonControls.containsKey(c.id)) return
            activeButtonControls[c.id] = id
            b.touch(MotionEvent.ACTION_DOWN, id, x, y)
        } else {
            if (activeButtonControls.remove(c.id) == null) return
            b.touch(MotionEvent.ACTION_UP, id, x, y)
        }
        updateRecoilState()
    }

    fun onMouseButtons(state: Int) {
        if (!enabled.value) return
        val changed = state xor mouseButtons
        mouseButtons = state
        for (c in controls.value) {
            if (c.type != ControlType.BUTTON || c.mouseButton == 0) continue
            if ((c.mouseButton and 0xFFFF) == 0) continue
            if ((changed and c.mouseButton) != 0) setButton(c, (state and c.mouseButton) != 0)
        }
    }

    fun onScroll(v: Float) {
        if (!enabled.value || v == 0f) return
        val want = if (v > 0) MouseBtn.SCROLL_UP else MouseBtn.SCROLL_DOWN
        for (c in controls.value) {
            if (c.type == ControlType.BUTTON && c.mouseButton == want) {
                setButton(c, true)
                handler.postDelayed({ setButton(c, false) }, 45)
            }
        }
    }

    private fun updateRecoilState() {
        val fireDown = controls.value.any { it.isFire && activeButtonControls.containsKey(it.id) }
        val p = profile.value
        val hold = fireDown && p?.recoilEnabled == true
        if (hold != recoilHolding.value) recoilHolding.value = hold
        if (hold) scheduleTick()
    }

    // ---------------- Câmera (movimento do mouse) ----------------

    fun onMouseMove(dx: Float, dy: Float) {
        if (!enabled.value) return
        if (controls.value.none { it.type == ControlType.CAMERA }) return
        pendDx += dx
        pendDy += dy
        scheduleTick()
    }

    private fun scheduleTick() {
        if (ticking) return
        ticking = true
        lastTick = SystemClock.uptimeMillis()
        handler.postDelayed(tick, periodMs())
    }

    private fun periodMs(): Long = when (profile.value?.pollingHz) {
        500 -> 2L
        125 -> 8L
        else -> 4L
    }

    private val tick = object : Runnable {
        override fun run() {
            val p = profile.value
            val cam = controls.value.firstOrNull { it.type == ControlType.CAMERA }
            val b = backend
            if (!enabled.value || p == null || cam == null || b == null) {
                ticking = false
                return
            }
            val now = SystemClock.uptimeMillis()
            val dt = ((now - lastTick).coerceIn(1, 100)) / 1000f
            lastTick = now

            // 1) entrada bruta acumulada no intervalo -> sensibilidade
            var dx = pendDx
            var dy = pendDy
            pendDx = 0f; pendDy = 0f
            val speed = hypot(dx, dy) / dt // px/s
            val accelFactor = 1f + p.accel * min(speed / 3000f, 2f)
            val mul = p.speedMul * accelFactor
            dx *= p.sensX * mul * (if (p.invertX) -1f else 1f)
            dy *= p.sensY * mul * (if (p.invertY) -1f else 1f)

            // 2) suavização exponencial (0 = nenhuma)
            val a = (1f - p.smoothing.coerceIn(0f, 0.95f))
            smDx += (dx - smDx) * a
            smDy += (dy - smDy) * a
            var outX = smDx
            var outY = smDy

            // 3) compensação de movimento enquanto o botão de disparo está pressionado
            if (recoilHolding.value) {
                outX += p.recoilX * p.recoilIntensity * dt
                outY += p.recoilY * p.recoilIntensity * dt
            }

            if (abs(outX) > 0.05f || abs(outY) > 0.05f) moveCamera(b, cam, outX, outY)

            val moving = abs(smDx) > 0.05f || abs(smDy) > 0.05f || pendDx != 0f || pendDy != 0f || recoilHolding.value
            if (moving) handler.postDelayed(this, periodMs()) else {
                ticking = false
                if (camActive) {
                    b.touch(MotionEvent.ACTION_UP, ID_CAM, camX, camY)
                    camActive = false
                }
            }
        }
    }

    private fun moveCamera(b: InputBackend, cam: ControlEntity, dx: Float, dy: Float) {
        val s = screen()
        camCx = cam.x * s.x
        camCy = cam.y * s.y
        val radius = cam.size * min(s.x, s.y) / 2f
        if (!camActive) {
            camX = camCx; camY = camCy
            b.touch(MotionEvent.ACTION_DOWN, ID_CAM, camX, camY)
            camActive = true
        }
        camX += dx
        camY += dy
        // Ao sair da área, solta e reinicia o arrasto no centro (como um "levantar o mouse").
        if (hypot(camX - camCx, camY - camCy) > radius * CAM_HOLD_RESET_PX) {
            b.touch(MotionEvent.ACTION_UP, ID_CAM, camX, camY)
            camX = camCx + dx; camY = camCy + dy
            b.touch(MotionEvent.ACTION_DOWN, ID_CAM, camCx, camCy)
            b.touch(MotionEvent.ACTION_MOVE, ID_CAM, camX, camY)
            return
        }
        camX = camX.coerceIn(0f, s.x - 1f)
        camY = camY.coerceIn(0f, s.y - 1f)
        b.touch(MotionEvent.ACTION_MOVE, ID_CAM, camX, camY)
    }

    // ---------------- Edição do perfil ativo ----------------

    suspend fun updateProfile(transform: (ProfileEntity) -> ProfileEntity) {
        val p = profile.value ?: return
        repo.update(transform(p))
    }
}
