package com.keymapperpro.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.keymapperpro.Route
import com.keymapperpro.core.ActivationMode
import com.keymapperpro.service.FloatingService
import com.keymapperpro.ui.theme.Bar
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.Tone

@Composable
fun DashboardScreen(navigate: (Route) -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val act by c.activation.status.collectAsState()
    val backend by c.activation.backend.collectAsState()
    val enabled by c.engine.enabled.collectAsState()
    val profile by c.engine.profile.collectAsState()
    val devices by c.devices.devices.collectAsState()
    val ram by c.ram.info.collectAsState()
    val disp by c.screen.state.collectAsState()
    val svc by FloatingService.running.collectAsState()
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        c.ram.acquire()
        onDispose { c.ram.release() }
    }
    LaunchedEffect(backend) { c.screen.refresh() }

    ScreenColumn("Dashboard", "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})") {
        GCard(title = "Mapeamento", accent = enabled) {
            StatusRow("Estado", if (enabled) "Ativo" else "Parado", if (enabled) Tone.OK else Tone.OFF)
            StatusRow("Perfil ativo", profile?.name ?: "nenhum", if (profile != null) Tone.OK else Tone.WARN)
            error?.let { Notice(it, Tone.ERR) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!enabled) {
                    GButton("Iniciar mapeamento", { error = startMapping(ctx, c) }, Modifier.weight(1f))
                } else {
                    GButton("Parar", { c.engine.setEnabled(false); error = null }, Modifier.weight(1f))
                }
                GOutlined(if (svc) "Fechar painel" else "Abrir painel", {
                    if (svc) FloatingService.stop(ctx)
                    else if (!android.provider.Settings.canDrawOverlays(ctx)) error = "Conceda a permissão de sobreposição (Ativação)."
                    else FloatingService.start(ctx)
                }, Modifier.weight(1f))
            }
        }

        GCard(title = "Ativação") {
            StatusRow(
                "Método selecionado",
                when (act.mode) { ActivationMode.SHIZUKU -> "Shizuku"; ActivationMode.ROOT -> "Root"; ActivationMode.NO_ROOT -> "Sem root" },
                Tone.OFF,
            )
            StatusRow(
                "Conexão", backend?.name?.let { "Conectado: $it" } ?: "Não conectado",
                if (backend != null) Tone.OK else Tone.WARN,
            )
            StatusRow("Sobreposição", if (act.overlay) "Permitida" else "Pendente", if (act.overlay) Tone.OK else Tone.ERR)
            if (backend == null) GOutlined("Configurar ativação", { navigate(Route.Activation) }, Modifier.fillMaxWidth())
        }

        GCard(title = "Dispositivos de entrada") {
            val kb = devices.filter { it.isKeyboard }
            val ms = devices.filter { it.isMouse }
            StatusRow("Teclado", kb.firstOrNull()?.name ?: "não detectado", if (kb.isNotEmpty()) Tone.OK else Tone.WARN)
            StatusRow("Mouse", ms.firstOrNull()?.name ?: "não detectado", if (ms.isNotEmpty()) Tone.OK else Tone.WARN)
        }

        GCard(title = "Sistema") {
            StatusRow("RAM utilizada", "${ram.usedMb} / ${ram.totalMb} MB", if (ram.usedPct > 85) Tone.WARN else Tone.OK)
            Bar(ram.usedPct / 100f)
            StatusRow(
                "Resolução atual",
                if (disp.curW > 0) "${disp.curW}x${disp.curH} • ${disp.curDpi} dpi" else "—",
                if (disp.overridden) Tone.WARN else Tone.OFF,
            )
        }
    }
}
