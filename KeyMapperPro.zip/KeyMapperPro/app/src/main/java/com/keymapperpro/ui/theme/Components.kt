package com.keymapperpro.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun GCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    accent: Boolean = false,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Gx.Surface),
        border = BorderStroke(1.dp, if (accent) Brush.horizontalGradient(listOf(Gx.Blue, Gx.Purple)) else Brush.linearGradient(listOf(Gx.Outline, Gx.Outline))),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (title != null) Text(title, style = MaterialTheme.typography.titleMedium, color = Gx.Text)
            content()
        }
    }
}

@Composable
fun StatusDot(color: Color, modifier: Modifier = Modifier) {
    val c by animateColorAsState(color, tween(300), label = "dot")
    Box(modifier.size(10.dp).clip(CircleShape).background(c))
}

enum class Tone { OK, WARN, ERR, OFF }

fun Tone.color() = when (this) {
    Tone.OK -> Gx.Ok
    Tone.WARN -> Gx.Warn
    Tone.ERR -> Gx.Err
    Tone.OFF -> Gx.TextDim
}

@Composable
fun StatusRow(label: String, value: String, tone: Tone, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        StatusDot(tone.color())
        Spacer(Modifier.width(10.dp))
        Text(label, color = Gx.TextDim, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, color = Gx.Text, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(46.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gx.Blue, disabledContainerColor = Gx.Outline),
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
fun GOutlined(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(46.dp),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (enabled) Gx.Purple else Gx.Outline),
    ) { Text(text, color = if (enabled) Gx.Text else Gx.TextDim) }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    format: (Float) -> String = { "%.2f".format(it) },
    onFinished: (() -> Unit)? = null,
) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = Gx.TextDim, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(format(value), color = Gx.Text, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            onValueChangeFinished = onFinished,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Gx.Blue, activeTrackColor = Gx.Purple, inactiveTrackColor = Gx.Outline,
            ),
        )
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit, hint: String? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Gx.Text, style = MaterialTheme.typography.bodyLarge)
            if (hint != null) Text(hint, color = Gx.TextDim, style = MaterialTheme.typography.bodySmall)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Gx.Purple, checkedThumbColor = Color.White),
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Gx.Blue else Gx.SurfaceHi, tween(200), label = "chip")
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(bg)
            .border(1.dp, if (selected) Gx.Blue else Gx.Outline, RoundedCornerShape(10.dp))
            .clickableNoRipple(onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, color = Color.White, style = MaterialTheme.typography.labelLarge) }
}

@Composable
fun Notice(text: String, tone: Tone = Tone.WARN) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(tone.color().copy(alpha = 0.12f))
            .border(1.dp, tone.color().copy(alpha = 0.4f), RoundedCornerShape(10.dp)).padding(10.dp),
    ) { Text(text, color = Gx.Text, style = MaterialTheme.typography.bodySmall) }
}

@Composable
fun Bar(fraction: Float, modifier: Modifier = Modifier) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(400), label = "bar")
    val color = when {
        f > 0.9f -> Gx.Err
        f > 0.75f -> Gx.Warn
        else -> Gx.Blue
    }
    Box(modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Gx.Outline)) {
        Box(Modifier.fillMaxWidth(f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(color))
    }
}
