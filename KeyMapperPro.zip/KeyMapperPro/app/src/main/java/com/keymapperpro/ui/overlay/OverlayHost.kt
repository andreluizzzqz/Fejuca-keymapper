package com.keymapperpro.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.keymapperpro.data.ControlEntity
import com.keymapperpro.data.ControlType
import com.keymapperpro.input.MappingEngine
import kotlin.math.min

/** Dono de ciclo de vida mínimo para hospedar Compose numa janela de Service. */
class OverlayLifecycle : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    init {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}

/** Cria/gerencia janelas TYPE_APPLICATION_OVERLAY. */
class OverlayHost(private val ctx: Context) {
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val owner = OverlayLifecycle()

    fun params(flags: Int, w: Int, h: Int, gravity: Int = Gravity.TOP or Gravity.START) =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

    fun compose(content: @Composable () -> Unit): ComposeView {
        val v = ComposeView(ctx)
        v.setViewTreeLifecycleOwner(owner)
        v.setViewTreeViewModelStoreOwner(owner)
        v.setViewTreeSavedStateRegistryOwner(owner)
        v.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindowOrReleasedFromPool)
        v.setContent(content)
        return v
    }

    fun add(view: View, lp: WindowManager.LayoutParams): Boolean = try {
        wm.addView(view, lp)
        true
    } catch (e: Exception) {
        false
    }

    fun remove(view: View?) {
        if (view == null) return
        try {
            wm.removeView(view)
        } catch (_: Exception) {
        }
    }

    fun update(view: View, lp: WindowManager.LayoutParams) {
        try {
            wm.updateViewLayout(view, lp)
        } catch (_: Exception) {
        }
    }

    fun destroy() = owner.destroy()
}

/**
 * Janela de tela cheia, NÃO tocável (os toques reais e os injetados passam direto para o jogo)
 * mas focável: precisa de foco para receber o mouse capturado (Pointer Capture, Android 8+)
 * e as teclas quando o serviço de acessibilidade não está ativo.
 * Também desenha os controles, apenas como guia visual.
 */
class MappingOverlayView(ctx: Context, private val engine: MappingEngine) : View(ctx) {
    private var controls: List<ControlEntity> = emptyList()
    private var showGuides = true
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 30f; isFakeBoldText = true
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setOnCapturedPointerListener { _, e -> handleCaptured(e); true }
    }

    fun setData(c: List<ControlEntity>, guides: Boolean) {
        controls = c
        showGuides = guides
        invalidate()
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            requestFocus()
            requestPointerCapture()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post { requestFocus(); requestPointerCapture() }
    }

    override fun onDetachedFromWindow() {
        releasePointerCapture()
        super.onDetachedFromWindow()
    }

    override fun onPointerCaptureChange(hasCapture: Boolean) {
        super.onPointerCaptureChange(hasCapture)
        if (!hasCapture && engine.enabled.value) post { requestPointerCapture() }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (engine.onKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    private var lastButtons = 0

    private fun handleCaptured(e: MotionEvent) {
        if ((e.source and InputDevice.SOURCE_MOUSE_RELATIVE) == 0 && (e.source and InputDevice.SOURCE_MOUSE) == 0 &&
            (e.source and InputDevice.SOURCE_TOUCHPAD) == 0
        ) return
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> engine.onMouseMove(e.x, e.y)
            MotionEvent.ACTION_SCROLL -> engine.onScroll(e.getAxisValue(MotionEvent.AXIS_VSCROLL))
            MotionEvent.ACTION_BUTTON_PRESS, MotionEvent.ACTION_BUTTON_RELEASE,
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP -> {
                lastButtons = e.buttonState
                engine.onMouseButtons(e.buttonState)
            }
        }
        if (e.actionMasked == MotionEvent.ACTION_MOVE && e.buttonState != lastButtons) {
            lastButtons = e.buttonState
            engine.onMouseButtons(e.buttonState)
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (!showGuides) return
        val w = width.toFloat()
        val h = height.toFloat()
        val m = min(w, h)
        for (c in controls) {
            val cx = c.x * w
            val cy = c.y * h
            val r = c.size * m / 2f
            val a = (c.alpha * 255).toInt().coerceIn(20, 255)
            when (c.type) {
                ControlType.CAMERA -> {
                    stroke.color = Color.argb(a / 2, 157, 92, 255)
                    stroke.pathEffect = android.graphics.DashPathEffect(floatArrayOf(18f, 14f), 0f)
                    canvas.drawCircle(cx, cy, r, stroke)
                    stroke.pathEffect = null
                }
                else -> {
                    fill.color = Color.argb(a / 3, 76, 141, 255)
                    stroke.color = Color.argb(a, 76, 141, 255)
                    canvas.drawCircle(cx, cy, r, fill)
                    canvas.drawCircle(cx, cy, r, stroke)
                    text.color = Color.argb(a, 255, 255, 255)
                    text.textSize = (r * 0.5f).coerceIn(18f, 40f)
                    canvas.drawText(c.label.ifBlank { keyLabel(c) }, cx, cy + text.textSize / 3, text)
                }
            }
        }
    }

    private fun keyLabel(c: ControlEntity) = if (c.keyCode != 0) KeyEvent.keyCodeToString(c.keyCode).removePrefix("KEYCODE_") else "?"
}
