package com.keymapperpro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.keymapperpro.Route
import com.keymapperpro.data.Keys
import com.keymapperpro.data.ProfileEntity
import com.keymapperpro.service.FloatingService
import com.keymapperpro.ui.overlay.keyName
import com.keymapperpro.ui.theme.Chip
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MapperScreen(navigate: (Route) -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val devices by c.devices.devices.collectAsState()
    val profiles by c.repo.profiles.collectAsState(initial = emptyList())
    val settings by c.settings.flow.collectAsState(initial = com.keymapperpro.data.Settings())
    val enabled by c.engine.enabled.collectAsState()
    val controls by c.engine.controls.collectAsState()
    var error by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<ProfileEntity?>(null) }
    var deleting by remember { mutableStateOf<ProfileEntity?>(null) }

    ScreenColumn("Mapeador", "Teclado e mouse → toques na tela, por perfil.") {
        GCard(title = "Dispositivos detectados") {
            if (devices.isEmpty()) {
                Notice("Nenhum teclado ou mouse externo detectado. Conecte por USB (OTG) ou Bluetooth — a lista atualiza sozinha.")
            }
            devices.forEach { d ->
                StatusRow(
                    d.name,
                    listOfNotNull(if (d.isKeyboard) "Teclado" else null, if (d.isMouse) "Mouse" else null).joinToString(" + "),
                    Tone.OK,
                )
            }
        }

        GCard(title = "Mapeamento", accent = enabled) {
            StatusRow("Controles no perfil", controls.size.toString(), if (controls.isEmpty()) Tone.WARN else Tone.OK)
            StatusRow("Tecla liga/desliga", keyName(settings.toggleKey), Tone.OFF)
            error?.let { Notice(it, Tone.ERR) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (enabled) GButton("Parar", { c.engine.setEnabled(false) }, Modifier.weight(1f))
                else GButton("Iniciar", { error = startMapping(ctx, c) }, Modifier.weight(1f))
                GOutlined("Editor sobre o jogo", {
                    if (!android.provider.Settings.canDrawOverlays(ctx)) error = "Conceda a permissão de sobreposição (Ativação)."
                    else { error = null; FloatingService.start(ctx, FloatingService.ACTION_EDITOR) }
                }, Modifier.weight(1f))
            }
            GOutlined("Editar controles aqui", { navigate(Route.Editor) }, Modifier.fillMaxWidth())
            Text(
                "Sem o serviço de acessibilidade, as teclas só chegam enquanto a janela de captura do mapeamento está ativa. " +
                    "O mouse é capturado (cursor oculto) enquanto o mapeamento está ligado.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
        }

        GCard(title = "Perfis") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                profiles.forEach { p ->
                    Chip(p.name, p.id == settings.activeProfileId) {
                        scope.launch {
                            if (enabled) c.engine.setEnabled(false)
                            c.settings.set(Keys.activeProfile, p.id)
                        }
                    }
                }
            }
            val active = profiles.firstOrNull { it.id == settings.activeProfileId }
            if (active != null) {
                Text("Jogo: ${active.gamePackage}", color = Gx.TextDim, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GOutlined("Editar", { editing = active }, Modifier.weight(1f))
                    GOutlined("Duplicar", {
                        scope.launch {
                            val id = c.repo.duplicate(active.id)
                            if (id > 0) c.settings.set(Keys.activeProfile, id)
                        }
                    }, Modifier.weight(1f))
                    GOutlined("Excluir", { deleting = active }, Modifier.weight(1f), enabled = profiles.size > 1)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GOutlined("+ Modelo Free Fire", {
                    scope.launch {
                        val id = c.repo.createFreeFireProfile("Free Fire ${profiles.size + 1}")
                        c.settings.set(Keys.activeProfile, id)
                    }
                }, Modifier.weight(1f))
                GOutlined("+ Perfil vazio", {
                    scope.launch {
                        val id = c.repo.createEmpty("Perfil ${profiles.size + 1}")
                        c.settings.set(Keys.activeProfile, id)
                    }
                }, Modifier.weight(1f))
            }
        }
    }

    editing?.let { p ->
        var name by remember(p.id) { mutableStateOf(p.name) }
        var pkg by remember(p.id) { mutableStateOf(p.gamePackage) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Editar perfil") },
            text = {
                androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it.take(24) }, label = { Text("Nome") }, singleLine = true)
                    OutlinedTextField(pkg, { pkg = it.trim() }, label = { Text("Pacote do jogo") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Chip("Free Fire", pkg == "com.dts.freefireth") { pkg = "com.dts.freefireth" }
                        Chip("Free Fire MAX", pkg == "com.dts.freefiremax") { pkg = "com.dts.freefiremax" }
                    }
                }
            },
            confirmButton = {
                TextButton({
                    scope.launch { c.repo.update(p.copy(name = name.ifBlank { p.name }, gamePackage = pkg)) }
                    editing = null
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton({ editing = null }) { Text("Cancelar") } },
        )
    }
    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Excluir perfil?") },
            text = { Text("\"${p.name}\" e todos os seus controles serão removidos.") },
            confirmButton = {
                TextButton({
                    scope.launch {
                        if (enabled) c.engine.setEnabled(false)
                        val other = profiles.firstOrNull { it.id != p.id }
                        if (other != null) c.settings.set(Keys.activeProfile, other.id)
                        c.repo.delete(p.id)
                    }
                    deleting = null
                }) { Text("Excluir") }
            },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancelar") } },
        )
    }
}
