package com.keymapperpro.core

import android.Manifest
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.keymapperpro.BuildConfig
import com.keymapperpro.IPrivilegedService
import com.keymapperpro.data.Keys
import com.keymapperpro.data.SettingsStore
import com.keymapperpro.privileged.PrivilegedService
import com.keymapperpro.service.KeyMapperAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit

data class ActivationStatus(
    val shizukuInstalled: Boolean = false,
    val shizukuRunning: Boolean = false,
    val shizukuPreV11: Boolean = false,
    val shizukuPermission: Boolean = false,
    val shizukuConnected: Boolean = false,
    val rootChecked: Boolean = false,
    val rootAvailable: Boolean = false,
    val rootConnected: Boolean = false,
    val accessibility: Boolean = false,
    val overlay: Boolean = false,
    val notifications: Boolean = true,
    val mode: ActivationMode = ActivationMode.NO_ROOT,
    val message: String? = null,
)

enum class DiagLevel { OK, WARN, FAIL }
data class DiagItem(val title: String, val level: DiagLevel, val detail: String)

/**
 * Detecta e conecta os três métodos de ativação. Nada é simulado: cada estado vem de uma
 * verificação real (ping do binder Shizuku, `su -c id`, serviço de acessibilidade conectado).
 */
class ActivationManager(
    private val app: Application,
    private val settings: SettingsStore,
    private val scope: CoroutineScope,
) {
    val status = MutableStateFlow(ActivationStatus())
    val backend = MutableStateFlow<InputBackend?>(null)

    private var shizukuSvc: IPrivilegedService? = null
    private var rootClient: RootClient? = null

    private val shizukuConn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            shizukuSvc = IPrivilegedService.Stub.asInterface(binder)
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            shizukuSvc = null
            refresh()
        }
    }

    init {
        scope.launch {
            settings.flow.collectLatest { s ->
                val m = runCatching { ActivationMode.valueOf(s.mode) }.getOrDefault(ActivationMode.NO_ROOT)
                status.value = status.value.copy(mode = m)
                if (m == ActivationMode.SHIZUKU) bindShizuku()
                recompute()
            }
        }
        scope.launch {
            KeyMapperAccessibilityService.instance.collectLatest { refresh() }
        }
        try {
            Shizuku.addBinderReceivedListenerSticky {
                refresh()
                if (status.value.mode == ActivationMode.SHIZUKU) bindShizuku()
            }
            Shizuku.addBinderDeadListener {
                shizukuSvc = null
                refresh()
            }
            Shizuku.addRequestPermissionResultListener { _, result ->
                refresh()
                if (result == PackageManager.PERMISSION_GRANTED) bindShizuku()
            }
        } catch (_: Throwable) {
        }
        refresh()
    }

    // -------- Verificações --------

    fun refresh() {
        val pm = app.packageManager
        val installed = try {
            pm.getPackageInfo("moe.shizuku.privileged.api", 0); true
        } catch (_: Exception) {
            false
        }
        val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        val preV11 = running && try { Shizuku.isPreV11() } catch (_: Throwable) { false }
        val perm = running && !preV11 && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
        val notif = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        status.value = status.value.copy(
            shizukuInstalled = installed,
            shizukuRunning = running,
            shizukuPreV11 = preV11,
            shizukuPermission = perm,
            shizukuConnected = shizukuSvc != null && running,
            rootConnected = rootClient?.connected == true,
            accessibility = KeyMapperAccessibilityService.instance.value != null,
            overlay = Settings.canDrawOverlays(app),
            notifications = notif,
        )
        recompute()
    }

    private fun recompute() {
        val s = status.value
        val next: InputBackend? = when (s.mode) {
            ActivationMode.SHIZUKU -> shizukuSvc?.takeIf { s.shizukuConnected }?.let { ShizukuBackend(it) }
            ActivationMode.ROOT -> rootClient?.takeIf { it.connected }?.let { RootBackend(it) }
            ActivationMode.NO_ROOT ->
                KeyMapperAccessibilityService.instance.value?.injector?.let { AccessibilityBackend(it) }
        }
        val cur = backend.value
        if (cur == null && next == null) return
        if (cur != null && next != null && cur.name == next.name && sameTarget(cur, next)) return
        backend.value = next
    }

    private fun sameTarget(a: InputBackend, b: InputBackend): Boolean = when {
        a is ShizukuBackend && b is ShizukuBackend -> a.svc === b.svc
        a is RootBackend && b is RootBackend -> true
        a is AccessibilityBackend && b is AccessibilityBackend -> true
        else -> false
    }

    // -------- Ações --------

    suspend fun selectMode(mode: ActivationMode) {
        settings.set(Keys.mode, mode.name)
        status.value = status.value.copy(mode = mode, message = null)
        when (mode) {
            ActivationMode.SHIZUKU -> connectShizuku()
            ActivationMode.ROOT -> connectRoot()
            ActivationMode.NO_ROOT -> refresh()
        }
    }

    fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                msg("Shizuku não está em execução. Abra o app Shizuku e inicie o serviço.")
                return
            }
            if (Shizuku.isPreV11()) {
                msg("Versão do Shizuku muito antiga. Atualize o app Shizuku.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindShizuku()
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                msg("Permissão negada permanentemente. Conceda em Shizuku > Aplicativos autorizados.")
            } else {
                Shizuku.requestPermission(4242)
            }
        } catch (e: Throwable) {
            msg("Erro Shizuku: ${e.message}")
        }
    }

    fun connectShizuku() {
        refresh()
        requestShizukuPermission()
    }

    private fun bindShizuku() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) return
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return
            if (shizukuSvc != null) return
            val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, PrivilegedService::class.java.name))
                .daemon(false)
                .processNameSuffix("privileged")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE)
            Shizuku.bindUserService(args, shizukuConn)
        } catch (e: Throwable) {
            msg("Falha ao conectar ao serviço Shizuku: ${e.message}")
        }
    }

    /** Executa `su -c id`: dispara o pedido do gerenciador de root. Só chamado por ação do usuário. */
    suspend fun detectRoot(): Boolean = withContext(Dispatchers.IO) {
        val ok = try {
            val p = ProcessBuilder("su", "-c", "id -u").redirectErrorStream(true).start()
            val done = p.waitFor(20, TimeUnit.SECONDS)
            done && p.exitValue() == 0 && p.inputStream.bufferedReader().readText().trim() == "0"
        } catch (_: Exception) {
            false
        }
        status.value = status.value.copy(
            rootChecked = true,
            rootAvailable = ok,
            message = if (ok) null else "Root não disponível ou acesso negado pelo gerenciador de root.",
        )
        ok
    }

    suspend fun connectRoot(): Boolean {
        if (!status.value.rootAvailable && !detectRoot()) return false
        val token = settings.ensureRootToken()
        val client = rootClient ?: RootClient(app, token).also { rootClient = it }
        val ok = client.startServerAndConnect()
        if (!ok) msg("Não foi possível iniciar o serviço root.")
        refresh()
        return ok
    }

    fun disconnect() {
        try {
            shizukuSvc?.releaseAll()
        } catch (_: Exception) {
        }
        rootClient?.stopServer()
        refresh()
    }

    private fun msg(text: String) {
        status.value = status.value.copy(message = text)
    }

    fun diagnostics(): List<DiagItem> {
        val s = status.value
        val l = mutableListOf<DiagItem>()
        l += DiagItem(
            "Android", DiagLevel.OK,
            "API ${Build.VERSION.SDK_INT} • ${Build.MANUFACTURER} ${Build.MODEL}"
        )
        l += when {
            !s.shizukuInstalled -> DiagItem("Shizuku", DiagLevel.WARN, "App Shizuku não instalado.")
            !s.shizukuRunning -> DiagItem("Shizuku", DiagLevel.WARN, "Instalado, mas o serviço não está em execução.")
            s.shizukuPreV11 -> DiagItem("Shizuku", DiagLevel.FAIL, "Versão antiga (pré-v11). Atualize.")
            !s.shizukuPermission -> DiagItem("Shizuku", DiagLevel.WARN, "Em execução; falta conceder permissão a este app.")
            !s.shizukuConnected -> DiagItem("Shizuku", DiagLevel.WARN, "Permissão ok; serviço privilegiado ainda não conectado.")
            else -> DiagItem("Shizuku", DiagLevel.OK, "Conectado (uid shell).")
        }
        l += when {
            !s.rootChecked -> DiagItem("Root", DiagLevel.WARN, "Ainda não verificado. Toque em \"Detectar root\".")
            !s.rootAvailable -> DiagItem("Root", DiagLevel.WARN, "Indisponível ou negado.")
            !s.rootConnected -> DiagItem("Root", DiagLevel.WARN, "Root disponível; serviço ainda não iniciado.")
            else -> DiagItem("Root", DiagLevel.OK, "Daemon root conectado.")
        }
        l += if (s.accessibility) DiagItem("Acessibilidade", DiagLevel.OK, "Serviço ativo (gestos + teclas).")
        else DiagItem(
            "Acessibilidade", DiagLevel.WARN,
            "Desativado. Necessário no modo sem root; recomendado nos demais para capturar o teclado."
        )
        l += if (s.overlay) DiagItem("Sobreposição", DiagLevel.OK, "Permitida.")
        else DiagItem("Sobreposição", DiagLevel.FAIL, "Necessária para painel, editor e captura do mouse.")
        l += if (s.notifications) DiagItem("Notificações", DiagLevel.OK, "Permitidas.")
        else DiagItem("Notificações", DiagLevel.WARN, "Negadas: a notificação do serviço em primeiro plano ficará oculta.")
        if (Build.VERSION.SDK_INT >= 33 && !s.accessibility) {
            l += DiagItem(
                "Configuração restrita", DiagLevel.WARN,
                "Android 13+: em apps instalados fora da Play Store, abra Informações do app > ⋮ > \"Permitir configurações restritas\" antes de ativar a acessibilidade."
            )
        }
        return l
    }

    /** Motivo pelo qual o mapeamento não pode iniciar agora, ou null se tudo pronto. */
    fun readinessIssue(): String? {
        val s = status.value
        if (!s.overlay) return "Conceda a permissão de sobreposição na tela de Ativação."
        if (backend.value == null) {
            return when (s.mode) {
                ActivationMode.SHIZUKU -> "Shizuku não conectado. Veja a tela de Ativação."
                ActivationMode.ROOT -> "Root não conectado. Veja a tela de Ativação."
                ActivationMode.NO_ROOT -> "Ative o serviço de acessibilidade na tela de Ativação."
            }
        }
        return null
    }
}
