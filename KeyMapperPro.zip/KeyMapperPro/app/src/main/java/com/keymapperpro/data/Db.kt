package com.keymapperpro.data

import android.content.Context
import android.view.KeyEvent
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val gamePackage: String = "com.dts.freefireth",
    // Sensibilidade do mouse
    val sensX: Float = 1f,
    val sensY: Float = 1f,
    val accel: Float = 0f,
    val speedMul: Float = 1f,
    val smoothing: Float = 0.2f,
    val invertX: Boolean = false,
    val invertY: Boolean = false,
    val pollingHz: Int = 250,
    // Compensação de movimento (recuo): px/s aplicados enquanto um controle "disparo" está pressionado
    val recoilEnabled: Boolean = false,
    val recoilX: Float = 0f,
    val recoilY: Float = 0f,
    val recoilIntensity: Float = 1f,
)

object ControlType {
    const val BUTTON = "BUTTON"
    const val JOYSTICK = "JOYSTICK"
    const val CAMERA = "CAMERA"
}

/** Botão do mouse "virtual" para a roda: não existe em MotionEvent.BUTTON_*. */
object MouseBtn {
    const val SCROLL_UP = 0x10000
    const val SCROLL_DOWN = 0x20000
}

@Entity(
    tableName = "controls",
    foreignKeys = [ForeignKey(
        entity = ProfileEntity::class,
        parentColumns = ["id"],
        childColumns = ["profileId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("profileId")]
)
data class ControlEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val type: String = ControlType.BUTTON,
    val label: String = "",
    /** Posição e tamanho normalizados (0..1) => independem de resolução/rotação. */
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val size: Float = 0.10f,
    val alpha: Float = 0.6f,
    val keyCode: Int = 0,
    val mouseButton: Int = 0,
    val keyUp: Int = KeyEvent.KEYCODE_W,
    val keyDown: Int = KeyEvent.KEYCODE_S,
    val keyLeft: Int = KeyEvent.KEYCODE_A,
    val keyRight: Int = KeyEvent.KEYCODE_D,
    val isFire: Boolean = false,
)

@Dao
interface KeyMapperDao {
    @Query("SELECT * FROM profiles ORDER BY id")
    fun profiles(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM profiles WHERE id = :id")
    fun profileFlow(id: Long): Flow<ProfileEntity?>

    @Query("SELECT * FROM profiles WHERE id = :id")
    suspend fun profile(id: Long): ProfileEntity?

    @Query("SELECT COUNT(*) FROM profiles")
    suspend fun profileCount(): Int

    @Insert
    suspend fun insertProfile(p: ProfileEntity): Long

    @Update
    suspend fun updateProfile(p: ProfileEntity)

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun deleteProfile(id: Long)

    @Query("SELECT * FROM controls WHERE profileId = :pid ORDER BY id")
    fun controls(pid: Long): Flow<List<ControlEntity>>

    @Query("SELECT * FROM controls WHERE profileId = :pid ORDER BY id")
    suspend fun controlsOnce(pid: Long): List<ControlEntity>

    @Insert
    suspend fun insertControl(c: ControlEntity): Long

    @Update
    suspend fun updateControl(c: ControlEntity)

    @Delete
    suspend fun deleteControl(c: ControlEntity)
}

@Database(entities = [ProfileEntity::class, ControlEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): KeyMapperDao

    companion object {
        fun build(ctx: Context): AppDb =
            Room.databaseBuilder(ctx, AppDb::class.java, "keymapper.db").build()
    }
}
