package com.keymapperpro.ui.screens

import android.view.KeyEvent
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.keymapperpro.BuildConfig
import com.keymapperpro.data.Keys
import com.keymapperpro.ui.overlay.keyName
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.SwitchRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by c.settings.flow.collectAsState(initial = com.keymapperpro.data.Settings())
    var capturing by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(capturing) { if (capturing) runCatching { focus.requestFocus() } }

    ScreenColumn("Configurações") {
        GCard(title = "Mapeamento") {
            Text("Tecla para ligar/desligar o mapeamento: ${keyName(s.toggleKey)}", color = Gx.Text, style = MaterialTheme.typography.bodyMedium)
            GOutlined("Alterar tecla", { capturing = true }, Modifier.fillMaxWidth())
            if (capturing) {
                androidx.compose.ui.window.Dialog(onDismissRequest = { capturing = false }) {
                    GCard(title = "Pressione a nova tecla") {
                        androidx.compose.foundation.layout.Box(
                            Modifier.fillMaxWidth().focusRequester(focus).focusable().onPreviewKeyEvent { e ->
                                if (e.type == KeyEventType.KeyDown) {
                                    val code = e.key.nativeKeyCode
                                    capturing = false
                                    if (code != KeyEvent.KEYCODE_ESCAPE) scope.launch { c.settings.set(Keys.toggleKey, code) }
                                    true
                                } else false
                            }
                        ) { Text("Use o teclado conectado. Esc cancela.", color = Gx.TextDim) }
                        GOutlined("Cancelar", { capturing = false }, Modifier.fillMaxWidth())
                    }
                }
            }
            Text(
                "Funciona com o serviço de acessibilidade ativo (captura teclas com qualquer app em primeiro plano) " +
                    "ou, sem ele, enquanto o mapeamento já está ligado. Fora disso use o painel ou a notificação.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
            SwitchRow("Mostrar guias dos controles sobre o jogo", s.showControls, { v -> scope.launch { c.settings.set(Keys.showControls, v) } })
        }

        GCard(title = "Compatibilidade por fabricante") {
            Text(
                "• Xiaomi/MIUI/HyperOS: ative \"Janelas pop-up em segundo plano\" e \"Mostrar na tela de bloqueio\" nas permissões do app e deixe a economia de bateria em \"Sem restrições\".\n" +
                    "• Samsung One UI: Bateria > Sem restrições para este app; Acessibilidade > Apps instalados.\n" +
                    "• Huawei/Honor, OPPO, Vivo, Realme: permita inicialização automática e execução em segundo plano.\n" +
                    "• Android 13+: instalação fora da Play Store exige \"Permitir configurações restritas\" para ligar a acessibilidade.\n" +
                    "• Android 14+: o serviço em primeiro plano usa o tipo specialUse (declarado no manifesto).",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
        }

        GCard(title = "Limitações do Android (leia)") {
            Notice(
                "• Polling rate do mouse: não é alterável pelo Android; no app é só uma preferência de processamento.\n" +
                    "• Sem Shizuku/Root: toques por gestos (mais latência), sem resolução/DPI, sem FPS, sem consumo por app.\n" +
                    "• Captura do mouse: usa Pointer Capture (Android 8+) numa janela focável; alguns jogos podem reagir à perda de foco.\n" +
                    "• Jogos com anti-cheat podem detectar toques injetados e punir contas. Use por sua conta e risco.\n" +
                    "• Recuo: apenas compensação linear configurada por você; não lê o jogo.\n" +
                    "• RAM: só encerra processos em segundo plano; não aumenta FPS artificialmente.",
                Tone.WARN,
            )
        }

        GCard(title = "Sobre") {
            StatusRow("Versão", BuildConfig.VERSION_NAME, Tone.OFF)
            StatusRow("Pacote", ctx.packageName, Tone.OFF)
        }
    }
}
