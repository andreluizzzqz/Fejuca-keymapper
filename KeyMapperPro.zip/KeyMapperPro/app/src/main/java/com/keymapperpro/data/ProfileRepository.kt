package com.keymapperpro.data

import android.view.KeyEvent
import android.view.MotionEvent
import kotlinx.coroutines.flow.Flow

class ProfileRepository(private val dao: KeyMapperDao) {
    val profiles: Flow<List<ProfileEntity>> = dao.profiles()

    fun profile(id: Long): Flow<ProfileEntity?> = dao.profileFlow(id)
    fun controls(profileId: Long): Flow<List<ControlEntity>> = dao.controls(profileId)

    suspend fun update(p: ProfileEntity) = dao.updateProfile(p)
    suspend fun updateControl(c: ControlEntity) = dao.updateControl(c)
    suspend fun addControl(c: ControlEntity) = dao.insertControl(c)
    suspend fun deleteControl(c: ControlEntity) = dao.deleteControl(c)

    /** Cria o perfil inicial (modelo de Free Fire) se o banco estiver vazio. Retorna o id do perfil criado ou -1. */
    suspend fun ensureDefault(): Long {
        if (dao.profileCount() > 0) return -1
        return createFreeFireProfile("Free Fire (modelo)")
    }

    suspend fun createFreeFireProfile(name: String): Long {
        val id = dao.insertProfile(ProfileEntity(name = name))
        listOf(
            ControlEntity(profileId = id, type = ControlType.JOYSTICK, label = "WASD", x = 0.17f, y = 0.70f, size = 0.30f),
            ControlEntity(profileId = id, type = ControlType.CAMERA, label = "Câmera", x = 0.72f, y = 0.50f, size = 0.80f, alpha = 0.25f),
            ControlEntity(profileId = id, label = "Atirar", x = 0.86f, y = 0.62f, size = 0.14f, mouseButton = MotionEvent.BUTTON_PRIMARY, isFire = true),
            ControlEntity(profileId = id, label = "Mirar", x = 0.93f, y = 0.42f, size = 0.10f, mouseButton = MotionEvent.BUTTON_SECONDARY),
            ControlEntity(profileId = id, label = "Pular", x = 0.93f, y = 0.80f, size = 0.10f, keyCode = KeyEvent.KEYCODE_SPACE),
            ControlEntity(profileId = id, label = "Recarregar", x = 0.78f, y = 0.86f, size = 0.09f, keyCode = KeyEvent.KEYCODE_R),
            ControlEntity(profileId = id, label = "Agachar", x = 0.30f, y = 0.88f, size = 0.09f, keyCode = KeyEvent.KEYCODE_C),
        ).forEach { dao.insertControl(it) }
        return id
    }

    suspend fun createEmpty(name: String): Long = dao.insertProfile(ProfileEntity(name = name))

    suspend fun duplicate(id: Long): Long {
        val src = dao.profile(id) ?: return -1
        val newId = dao.insertProfile(src.copy(id = 0, name = src.name + " (cópia)"))
        dao.controlsOnce(id).forEach { dao.insertControl(it.copy(id = 0, profileId = newId)) }
        return newId
    }

    suspend fun delete(id: Long) = dao.deleteProfile(id)
}
