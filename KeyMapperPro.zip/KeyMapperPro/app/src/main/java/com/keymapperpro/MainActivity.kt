package com.keymapperpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.keymapperpro.ui.screens.ActivationScreen
import com.keymapperpro.ui.screens.DashboardScreen
import com.keymapperpro.ui.screens.EditorScreen
import com.keymapperpro.ui.screens.LocalContainer
import com.keymapperpro.ui.screens.MapperScreen
import com.keymapperpro.ui.screens.PanelScreen
import com.keymapperpro.ui.screens.RamScreen
import com.keymapperpro.ui.screens.RecoilScreen
import com.keymapperpro.ui.screens.ResolutionScreen
import com.keymapperpro.ui.screens.SensitivityScreen
import com.keymapperpro.ui.screens.SettingsScreen
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.KeyMapperTheme
import kotlinx.coroutines.launch

enum class Route(val path: String, val title: String, val icon: ImageVector) {
    Dashboard("dashboard", "Dashboard", Icons.Filled.Dashboard),
    Mapper("mapper", "Mapeador", Icons.Filled.Keyboard),
    Editor("editor", "Editor de controles", Icons.Filled.Edit),
    Sensitivity("sensitivity", "Sensibilidade", Icons.Filled.Mouse),
    Recoil("recoil", "Controle de recuo", Icons.Filled.MyLocation),
    Resolution("resolution", "Resolução e DPI", Icons.Filled.AspectRatio),
    Ram("ram", "Gerenciador de RAM", Icons.Filled.Memory),
    Panel("panel", "Painel flutuante", Icons.Filled.PictureInPicture),
    Activation("activation", "Ativação", Icons.Filled.Shield),
    Settings("settings", "Configurações", Icons.Filled.Settings),
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as KeyMapperApp).container
        setContent {
            KeyMapperTheme {
                CompositionLocalProvider(LocalContainer provides container) { AppRoot(container) }
            }
        }
    }
}

@Composable
private fun AppRoot(c: AppContainer) {
    val nav = rememberNavController()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStack by nav.currentBackStackEntryAsState()
    val current = Route.entries.firstOrNull { it.path == backStack?.destination?.route } ?: Route.Dashboard

    // Atualiza permissões/dispositivos ao voltar das telas de configuração do sistema
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        c.activation.refresh()
        c.devices.scan()
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Gx.Surface) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(8.dp)) {
                    Text("KeyMapper Pro", color = Gx.Blue, modifier = Modifier.padding(16.dp), style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
                    Route.entries.forEach { r ->
                        NavigationDrawerItem(
                            label = { Text(r.title) },
                            icon = { Icon(r.icon, null) },
                            selected = r == current,
                            onClick = {
                                scope.launch { drawer.close() }
                                go(nav, r)
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = Gx.SurfaceHi, selectedIconColor = Gx.Purple,
                                selectedTextColor = Gx.Text, unselectedTextColor = Gx.TextDim, unselectedIconColor = Gx.TextDim,
                            ),
                        )
                    }
                }
            }
        },
    ) {
        Column(Modifier.fillMaxSize().background(Gx.Bg).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ scope.launch { drawer.open() } }) { Icon(Icons.Filled.Menu, null, tint = Gx.Text) }
                Text(current.title, color = Gx.Text, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            }
            Box(Modifier.weight(1f)) {
                NavHost(
                    nav, startDestination = Route.Dashboard.path,
                    enterTransition = { fadeIn(tween(220)) },
                    exitTransition = { fadeOut(tween(160)) },
                ) {
                    composable(Route.Dashboard.path) { DashboardScreen { go(nav, it) } }
                    composable(Route.Mapper.path) { MapperScreen { go(nav, it) } }
                    composable(Route.Editor.path) { EditorScreen() }
                    composable(Route.Sensitivity.path) { SensitivityScreen() }
                    composable(Route.Recoil.path) { RecoilScreen() }
                    composable(Route.Resolution.path) { ResolutionScreen() }
                    composable(Route.Ram.path) { RamScreen() }
                    composable(Route.Panel.path) { PanelScreen() }
                    composable(Route.Activation.path) { ActivationScreen() }
                    composable(Route.Settings.path) { SettingsScreen() }
                }
            }
        }
    }
}

private fun go(nav: NavHostController, r: Route) {
    nav.navigate(r.path) {
        popUpTo(Route.Dashboard.path) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
