package com.keymapperpro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.keymapperpro.ui.theme.Chip
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.SliderRow
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ResolutionScreen() {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    val st by c.screen.state.collectAsState()
    val backend by c.activation.backend.collectAsState()
    val countdown by c.screen.countdown.collectAsState()
    val msg by c.screen.message.collectAsState()
    val busy by c.screen.busy.collectAsState()
    val original by c.settings.originalDisplay.collectAsState(initial = null)

    LaunchedEffect(backend) { c.screen.refresh() }

    var w by remember(st.curW) { mutableStateOf(st.curW.toString()) }
    var h by remember(st.curH) { mutableStateOf(st.curH.toString()) }
    var dpi by remember(st.curDpi) { mutableStateOf(st.curDpi.toFloat()) }

    val wi = w.toIntOrNull() ?: 0
    val hi = h.toIntOrNull() ?: 0
    val v = c.screen.validate(wi, hi, dpi.toInt())
    val canApply = c.screen.canApply

    ScreenColumn("Resolução e DPI", "Altera o tamanho e a densidade da tela do sistema (wm size / wm density).") {
        GCard(title = "Atual") {
            StatusRow("Resolução", "${st.curW} x ${st.curH}", if (st.overridden) Tone.WARN else Tone.OK)
            StatusRow("Densidade", "${st.curDpi} dpi", if (st.overridden) Tone.WARN else Tone.OK)
            if (st.physW > 0) {
                StatusRow("Original (física)", "${st.physW} x ${st.physH} • ${st.physDpi} dpi", Tone.OFF)
            }
            if (st.overridden) Notice("A tela está com valores alterados (override).", Tone.WARN)
        }

        if (!canApply) {
            Notice(
                "Alterar resolução exige Shizuku ou Root: o Android não permite isso a apps comuns. " +
                    "Sem eles você só vê os valores atuais. Ative um método na tela Ativação.",
                Tone.ERR,
            )
        }

        GCard(title = "Presets") {
            val presets = c.screen.presets()
            if (presets.isEmpty()) Text("Presets aparecem quando a resolução física é conhecida (Shizuku/Root).", color = Gx.TextDim)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { p ->
                    Chip("${p.label} • ${p.dpi}dpi", wi == p.w && hi == p.h && dpi.toInt() == p.dpi) {
                        w = p.w.toString(); h = p.h.toString(); dpi = p.dpi.toFloat()
                    }
                }
            }
        }

        GCard(title = "Personalizada") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    w, { w = it.filter(Char::isDigit).take(5) }, label = { Text("Largura") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    h, { h = it.filter(Char::isDigit).take(5) }, label = { Text("Altura") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                )
            }
            SliderRow("Densidade (DPI)", dpi, { dpi = it }, 120f..800f, { "${it.toInt()} dpi" })
            if (wi > 0 && hi > 0) {
                Text(
                    "Largura mínima resultante: ${(minOf(wi, hi) * 160f / dpi).toInt()} dp",
                    color = Gx.TextDim, style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                )
            }
            v.errors.forEach { Notice(it, Tone.ERR) }
            v.warnings.forEach { Notice(it, Tone.WARN) }
        }

        GCard(title = "Aplicar", accent = countdown > 0) {
            if (countdown > 0) {
                Notice("Confirme em ${countdown}s. Se a tela ficar ilegível, não faça nada: a configuração original volta sozinha.", Tone.WARN)
                GButton("Manter esta resolução", { scope.launch { c.screen.confirm() } }, Modifier.fillMaxWidth())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GButton("Aplicar", { scope.launch { c.screen.apply(wi, hi, dpi.toInt()) } }, Modifier.weight(1f),
                    enabled = canApply && v.ok && !busy && countdown == 0)
                GOutlined("Restaurar original", { scope.launch { c.screen.restore() } }, Modifier.weight(1f), enabled = canApply && !busy)
            }
            msg?.let { Text(it, color = Gx.TextDim, style = androidx.compose.material3.MaterialTheme.typography.bodySmall) }
            original?.let {
                Text("Original salvo: ${it.first} • ${it.second} dpi", color = Gx.TextDim, style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
            }
            Text(
                "Segurança: limites rígidos (lado ≥ ${com.keymapperpro.system.ScreenManager.MIN_SIDE}px, ≥ ${com.keymapperpro.system.ScreenManager.MIN_SW_DP}dp), " +
                    "reversão automática em ${com.keymapperpro.system.ScreenManager.CONFIRM_SECONDS}s sem confirmação, e um temporizador no shell que restaura mesmo se o app fechar. " +
                    "Se algo der errado: adb shell wm size reset && adb shell wm density reset.",
                color = Gx.TextDim, style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
            )
        }
    }
}
