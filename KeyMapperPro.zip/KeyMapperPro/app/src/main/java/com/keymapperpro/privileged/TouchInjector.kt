package com.keymapperpro.privileged

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.lang.reflect.Method

/**
 * Injeta eventos multitoque reais via IInputManager.
 * Só funciona em processo com permissão INJECT_EVENTS (shell/Shizuku ou root).
 * Roda dentro do processo privilegiado: não usa Context.
 */
class TouchInjector {
    private class Pt(val id: Int, var x: Float, var y: Float)

    private val inputManager: Any
    private val inject: Method
    private val setDisplayId: Method?
    private val points = ArrayList<Pt>()
    private var downTime = 0L

    init {
        try {
            HiddenApiBypass.addHiddenApiExemptions("L")
        } catch (_: Throwable) {
        }
        val binder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java)
            .invoke(null, "input") as IBinder
        inputManager = Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java)
            .invoke(null, binder)!!
        inject = inputManager.javaClass.methods.first {
            it.name == "injectInputEvent" && it.parameterTypes.size == 2 &&
                InputEvent::class.java.isAssignableFrom(it.parameterTypes[0])
        }
        setDisplayId = try {
            InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
        } catch (_: Throwable) {
            null
        }
    }

    @Synchronized
    fun touch(action: Int, id: Int, x: Float, y: Float) {
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                points.removeAll { it.id == id }
                points.add(Pt(id, x, y))
                if (points.size == 1) {
                    downTime = SystemClock.uptimeMillis()
                    send(MotionEvent.ACTION_DOWN, 0)
                } else {
                    send(MotionEvent.ACTION_POINTER_DOWN, points.size - 1)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val p = points.firstOrNull { it.id == id } ?: return
                p.x = x
                p.y = y
                send(MotionEvent.ACTION_MOVE, 0)
            }
            MotionEvent.ACTION_UP -> {
                val idx = points.indexOfFirst { it.id == id }
                if (idx < 0) return
                points[idx].x = x
                points[idx].y = y
                if (points.size == 1) send(MotionEvent.ACTION_UP, 0)
                else send(MotionEvent.ACTION_POINTER_UP, idx)
                points.removeAt(idx)
            }
        }
    }

    @Synchronized
    fun releaseAll() {
        while (points.isNotEmpty()) {
            val p = points.last()
            touch(MotionEvent.ACTION_UP, p.id, p.x, p.y)
        }
    }

    private fun send(action: Int, index: Int) {
        val n = points.size
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().apply {
                id = points[i].id
                toolType = MotionEvent.TOOL_TYPE_FINGER
            }
        }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().apply {
                x = points[i].x
                y = points[i].y
                pressure = 1f
                size = 1f
            }
        }
        val act = if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_POINTER_UP) {
            action or (index shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        } else action
        val now = SystemClock.uptimeMillis()
        val ev = MotionEvent.obtain(
            downTime, now, act, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            try {
                setDisplayId?.invoke(ev, 0)
            } catch (_: Throwable) {
            }
            inject.invoke(inputManager, ev, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } finally {
            ev.recycle()
        }
    }
}
