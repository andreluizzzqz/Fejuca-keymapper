package com.keymapperpro.system

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.keymapperpro.core.ActivationManager
import com.keymapperpro.data.ProfileEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class TelemetryState(
    val batteryTempC: Float? = null,
    val thermalStatus: String? = null,
    val fps: Float? = null,
    val fpsNote: String = "FPS exige Shizuku ou Root.",
)

/**
 * Temperatura: sensor da bateria (BatteryManager) + estado térmico do sistema (API 29+).
 * FPS: `dumpsys SurfaceFlinger --latency` da camada do jogo (shell). Em aparelhos/versões onde
 * a saída não existe, informa "indisponível" em vez de inventar um número.
 */
class Telemetry(
    private val app: Application,
    private val scope: CoroutineScope,
    private val activation: ActivationManager,
) {
    val state = MutableStateFlow(TelemetryState())
    private var job: Job? = null
    private var users = 0
    @Volatile var gamePackage: String? = null
    private var layer: String? = null
    private var layerPkg: String? = null

    fun acquire() {
        users++
        if (job?.isActive == true) return
        job = scope.launch(Dispatchers.IO) {
            var n = 0
            while (isActive) {
                readTemp()
                if (n % 1 == 0) readFps()
                n++
                delay(2000)
            }
        }
    }

    fun release() {
        users = (users - 1).coerceAtLeast(0)
        if (users == 0) {
            job?.cancel()
            job = null
        }
    }

    private fun readTemp() {
        val i: Intent? = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temp = if (t != null && t != Int.MIN_VALUE && t > 0) t / 10f else null
        var thermal: String? = null
        if (Build.VERSION.SDK_INT >= 29) {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            thermal = when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Leve"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderado"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severo"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Crítico"
                PowerManager.THERMAL_STATUS_EMERGENCY, PowerManager.THERMAL_STATUS_SHUTDOWN -> "Emergência"
                else -> null
            }
        }
        state.value = state.value.copy(batteryTempC = temp, thermalStatus = thermal)
    }

    private suspend fun readFps() {
        val b = activation.backend.value
        val pkg = gamePackage
        if (b == null || !b.canShell) {
            state.value = state.value.copy(fps = null, fpsNote = "FPS exige Shizuku ou Root.")
            return
        }
        if (pkg.isNullOrBlank()) {
            state.value = state.value.copy(fps = null, fpsNote = "Defina o pacote do jogo no perfil.")
            return
        }
        if (layer == null || layerPkg != pkg) {
            val list = b.exec("dumpsys SurfaceFlinger --list").out.lines().map { it.trim() }
            layer = list.firstOrNull { it.startsWith("SurfaceView[$pkg") && it.contains("BLAST").not() }
                ?: list.firstOrNull { it.startsWith("SurfaceView[$pkg") }
                ?: list.firstOrNull { it.contains(pkg) && !it.startsWith("Background") }
            layerPkg = pkg
        }
        val l = layer
        if (l == null) {
            state.value = state.value.copy(fps = null, fpsNote = "Jogo não encontrado na tela (abra o jogo).")
            return
        }
        val r = b.exec("dumpsys SurfaceFlinger --latency '${l.replace("'", "")}'")
        val ts = r.out.lines().drop(1).mapNotNull {
            it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull()
        }.filter { it in 1 until Long.MAX_VALUE / 2 }
        if (!r.ok || ts.size < 5) {
            layer = null
            state.value = state.value.copy(fps = null, fpsNote = "Este aparelho não expõe latência de frames.")
            return
        }
        val newest = ts.max()
        val window = ts.filter { it > newest - 1_000_000_000L }
        val span = (window.max() - window.min()) / 1e9f
        val fps = if (window.size >= 2 && span > 0.2f) (window.size - 1) / span else null
        state.value = state.value.copy(fps = fps, fpsNote = if (fps == null) "Sem frames recentes." else "")
    }
}
