package com.keymapperpro.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.keymapperpro.service.FloatingService
import com.keymapperpro.ui.overlay.ControlEditor
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Editor dentro do app. Usa a proporção real da tela em paisagem para que tamanhos e posições
 * (relativos à tela, 0–100%) fiquem idênticos ao que aparece no jogo.
 */
@Composable
fun EditorScreen() {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile by c.engine.profile.collectAsState()
    val controls by c.engine.controls.collectAsState()
    val disp by c.screen.state.collectAsState()
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    androidx.compose.runtime.LaunchedEffect(Unit) { c.screen.refresh() }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val p = profile
        if (p == null) {
            Notice("Nenhum perfil ativo. Crie ou selecione um na tela Mapeador.", Tone.WARN)
            return@Column
        }
        Text("Perfil: ${p.name}", color = Gx.Text, style = MaterialTheme.typography.titleMedium)
        if (!landscape) {
            Notice("Gire o aparelho para paisagem para editar aqui com a proporção real da tela — ou use o editor sobre o jogo.", Tone.WARN)
            Text(
                "${controls.size} controle(s) neste perfil.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
            GOutlined("Abrir editor sobre o jogo", {
                if (android.provider.Settings.canDrawOverlays(ctx)) FloatingService.start(ctx, FloatingService.ACTION_EDITOR)
            }, Modifier.fillMaxWidth())
            return@Column
        }
        val ratio = if (disp.curW > 0 && disp.curH > 0) maxOf(disp.curW, disp.curH).toFloat() / minOf(disp.curW, disp.curH) else 2f
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            ControlEditor(
                profileId = p.id,
                controls = controls,
                onAdd = { scope.launch(Dispatchers.IO) { c.repo.addControl(it) } },
                onSave = { scope.launch(Dispatchers.IO) { c.repo.updateControl(it) } },
                onDelete = { scope.launch(Dispatchers.IO) { c.repo.deleteControl(it) } },
                overlay = false,
                onClose = null,
                modifier = Modifier.aspectRatio(ratio, matchHeightConstraintsFirst = true),
            )
        }
    }
}
