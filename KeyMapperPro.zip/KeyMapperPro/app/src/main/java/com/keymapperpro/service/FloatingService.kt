package com.keymapperpro.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.keymapperpro.AppContainer
import com.keymapperpro.KeyMapperApp
import com.keymapperpro.MainActivity
import com.keymapperpro.ui.overlay.ControlEditor
import com.keymapperpro.ui.overlay.FloatingPanel
import com.keymapperpro.ui.overlay.MappingOverlayView
import com.keymapperpro.ui.overlay.OverlayHost
import com.keymapperpro.ui.theme.KeyMapperTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Serviço em primeiro plano que hospeda as janelas flutuantes:
 *  - painel (sempre que o serviço roda);
 *  - sobreposição de mapeamento (apenas enquanto o mapeamento está ativo);
 *  - editor visual (sob demanda; pausa o mapeamento).
 */
class FloatingService : Service() {
    companion object {
        val running = MutableStateFlow(false)
        const val ACTION_START = "com.keymapperpro.START"
        const val ACTION_EDITOR = "com.keymapperpro.EDITOR"
        const val ACTION_TOGGLE = "com.keymapperpro.TOGGLE"
        const val ACTION_STOP = "com.keymapperpro.STOP"
        private const val CHANNEL = "keymapper_fg"
        private const val NOTIF_ID = 17

        fun start(ctx: Context, action: String = ACTION_START) {
            val i = Intent(ctx, FloatingService::class.java).setAction(action)
            androidx.core.content.ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingService::class.java).setAction(ACTION_STOP))
        }
    }

    private lateinit var c: AppContainer
    private lateinit var host: OverlayHost
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var panelView: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var mappingView: MappingOverlayView? = null
    private var editorView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        c = (application as KeyMapperApp).container
        host = OverlayHost(this)
        running.value = true
        startForegroundCompat()
        c.devices.scan()

        // Painel: posição salva
        scope.launch {
            val s = c.settings.settingsOnce()
            showPanel(s.panelX, s.panelY)
        }

        // Sobreposição de mapeamento segue o estado do motor
        scope.launch {
            combine(c.engine.enabled, c.engine.controls, c.settings.flow) { en, ctrls, st -> Triple(en, ctrls, st.showControls) }
                .collectLatest { (en, ctrls, guides) ->
                    if (en) ensureMappingView(ctrls, guides) else removeMappingView()
                    updateNotification()
                }
        }
        // Pacote do jogo para o monitor de FPS
        scope.launch {
            c.engine.profile.collectLatest { c.telemetry.gamePackage = it?.gamePackage }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> c.engine.toggle()
            ACTION_EDITOR -> showEditor()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        c.engine.setEnabled(false)
        removeMappingView()
        removeEditor()
        host.remove(panelView)
        panelView = null
        host.destroy()
        scope.cancel()
        running.value = false
        super.onDestroy()
    }

    // ---------------- Janelas ----------------

    private fun showPanel(x: Int, y: Int) {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val lp = host.params(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        ).apply {
            this.x = x
            this.y = y
        }
        val v = host.compose {
            KeyMapperTheme {
                FloatingPanel(
                    c,
                    onDrag = { dx, dy ->
                        lp.x = (lp.x + dx.toInt()).coerceAtLeast(0)
                        lp.y = (lp.y + dy.toInt()).coerceAtLeast(0)
                        panelView?.let { host.update(it, lp) }
                    },
                    onDragEnd = { scope.launch { c.settings.setPanelPosition(lp.x, lp.y) } },
                    onClose = { stopSelf() },
                    onEditor = { showEditor() },
                    onOpenApp = {
                        startActivity(Intent(this@FloatingService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                    },
                )
            }
        }
        if (host.add(v, lp)) {
            panelView = v
            panelLp = lp
        } else stopSelf()
    }

    private fun ensureMappingView(controls: List<com.keymapperpro.data.ControlEntity>, guides: Boolean) {
        val existing = mappingView
        if (existing != null) {
            existing.setData(controls, guides)
            return
        }
        val v = MappingOverlayView(this, c.engine)
        val lp = host.params(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        )
        v.setData(controls, guides)
        // A janela é NOT_TOUCHABLE: o painel continua recebendo toques mesmo ficando por baixo.
        if (host.add(v, lp)) mappingView = v else c.engine.setEnabled(false)
    }

    private fun removeMappingView() {
        host.remove(mappingView)
        mappingView = null
    }

    private fun showEditor() {
        if (editorView != null) return
        c.engine.setEnabled(false)
        val pid = c.engine.profile.value?.id
        if (pid == null) {
            c.engine.lastError.value = "Selecione um perfil antes de abrir o editor."
            return
        }
        val lp = host.params(
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        )
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        val v = host.compose {
            KeyMapperTheme {
                val controls by c.engine.controls.collectAsState()
                ControlEditor(
                    profileId = pid,
                    controls = controls,
                    onAdd = { scope.launch(Dispatchers.IO) { c.repo.addControl(it) } },
                    onSave = { scope.launch(Dispatchers.IO) { c.repo.updateControl(it) } },
                    onDelete = { scope.launch(Dispatchers.IO) { c.repo.deleteControl(it) } },
                    overlay = true,
                    onClose = { removeEditor() },
                )
            }
        }
        if (host.add(v, lp)) editorView = v
    }

    private fun removeEditor() {
        host.remove(editorView)
        editorView = null
    }

    // ---------------- Notificação ----------------

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Painel e mapeamento", NotificationManager.IMPORTANCE_LOW))
        }
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, FloatingService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val on = c.engine.enabled.value
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("KeyMapper Pro")
            .setContentText(if (on) "Mapeamento ativo" else "Mapeamento pausado")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, if (on) "Pausar" else "Iniciar", pi(ACTION_TOGGLE, 1))
            .addAction(0, "Parar", pi(ACTION_STOP, 2))
            .build()
    }
}
