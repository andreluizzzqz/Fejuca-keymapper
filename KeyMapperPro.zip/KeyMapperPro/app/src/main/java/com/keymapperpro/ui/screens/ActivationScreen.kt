package com.keymapperpro.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.keymapperpro.core.ActivationMode
import com.keymapperpro.core.DiagLevel
import com.keymapperpro.ui.theme.Chip
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

@Composable
fun ActivationScreen() {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by c.activation.status.collectAsState()
    val backend by c.activation.backend.collectAsState()
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { c.activation.refresh() }

    ScreenColumn(
        "Ativação",
        "Cada status abaixo vem de uma verificação real do sistema. Nada é simulado."
    ) {
        GCard(title = "Método de ativação") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Shizuku", s.mode == ActivationMode.SHIZUKU) { scope.launch { c.activation.selectMode(ActivationMode.SHIZUKU) } }
                Chip("Root", s.mode == ActivationMode.ROOT) { scope.launch { c.activation.selectMode(ActivationMode.ROOT) } }
                Chip("Sem root", s.mode == ActivationMode.NO_ROOT) { scope.launch { c.activation.selectMode(ActivationMode.NO_ROOT) } }
            }
            StatusRow(
                "Conexão", backend?.let { "Conectado via ${it.name}" } ?: "Não conectado",
                if (backend != null) Tone.OK else Tone.ERR,
            )
            s.message?.let { Notice(it, Tone.WARN) }
            when (s.mode) {
                ActivationMode.SHIZUKU -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GButton("Ativar Shizuku", { c.activation.connectShizuku() }, Modifier.weight(1f), enabled = s.shizukuRunning)
                    GOutlined(if (s.shizukuInstalled) "Abrir Shizuku" else "Baixar Shizuku", { openShizuku(ctx) }, Modifier.weight(1f))
                }
                ActivationMode.ROOT -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GButton("Ativar Root", { scope.launch { c.activation.connectRoot() } }, Modifier.weight(1f))
                    GOutlined("Detectar root", { scope.launch { c.activation.detectRoot() } }, Modifier.weight(1f))
                }
                ActivationMode.NO_ROOT -> GButton("Ativar acessibilidade", { openAccessibilitySettings(ctx) }, Modifier.fillMaxWidth())
            }
            if (backend != null) GOutlined("Desconectar", { c.engine.setEnabled(false); c.activation.disconnect() }, Modifier.fillMaxWidth())
        }

        GCard(title = "Status") {
            StatusRow("Shizuku instalado", yn(s.shizukuInstalled), tone(s.shizukuInstalled))
            StatusRow("Shizuku em execução", yn(s.shizukuRunning), tone(s.shizukuRunning))
            StatusRow("Permissão Shizuku", yn(s.shizukuPermission), tone(s.shizukuPermission))
            StatusRow("Serviço Shizuku", if (s.shizukuConnected) "Conectado" else "Desconectado", tone(s.shizukuConnected))
            StatusRow(
                "Root", if (!s.rootChecked) "Não verificado" else if (s.rootAvailable) "Disponível" else "Indisponível",
                if (!s.rootChecked) Tone.OFF else tone(s.rootAvailable),
            )
            StatusRow("Serviço root", if (s.rootConnected) "Conectado" else "Desconectado", tone(s.rootConnected))
            StatusRow("Acessibilidade", if (s.accessibility) "Ativa" else "Inativa", tone(s.accessibility))
        }

        GCard(title = "Permissões") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GOutlined("Sobreposição", { openOverlaySettings(ctx) }, Modifier.weight(1f), enabled = !s.overlay)
                GOutlined("Acessibilidade", { openAccessibilitySettings(ctx) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GOutlined("Notificações", {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }, Modifier.weight(1f), enabled = !s.notifications)
                GOutlined("Info do app", { openAppInfo(ctx) }, Modifier.weight(1f))
            }
        }

        GCard(title = "Diagnóstico") {
            c.activation.diagnostics().forEach { d ->
                StatusRow(
                    d.title, d.detail,
                    when (d.level) { DiagLevel.OK -> Tone.OK; DiagLevel.WARN -> Tone.WARN; DiagLevel.FAIL -> Tone.ERR },
                )
            }
            GOutlined("Reverificar", { c.activation.refresh(); c.devices.scan() }, Modifier.fillMaxWidth())
        }

        GCard(title = "Como configurar") {
            Text(
                "SHIZUKU (recomendado)\n" +
                    "1. Instale o app Shizuku.\n" +
                    "2. Android 11+: ative Opções do desenvolvedor > Depuração sem fio e inicie o Shizuku por \"Pareamento\". " +
                    "Android 10: conecte ao PC e rode o comando mostrado no app Shizuku.\n" +
                    "3. Volte aqui, escolha Shizuku e toque em Ativar. Aceite a permissão.\n" +
                    "4. É preciso reiniciar o Shizuku após reiniciar o aparelho.\n\n" +
                    "ROOT\n" +
                    "1. Requer aparelho com root (Magisk/KernelSU).\n" +
                    "2. Escolha Root e toque em Ativar; conceda o pedido do gerenciador de root.\n\n" +
                    "SEM ROOT\n" +
                    "1. Toque em Ativar acessibilidade e ligue o KeyMapper Pro.\n" +
                    "2. Android 13+: se estiver bloqueado, abra Info do app > ⋮ > Permitir configurações restritas e tente de novo.\n" +
                    "3. Limitação: toques por gestos têm mais latência; não há controle de resolução, FPS nem consumo por app.\n\n" +
                    "TODOS: conceda Sobreposição e permita notificações.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

private fun yn(b: Boolean) = if (b) "Sim" else "Não"
private fun tone(b: Boolean) = if (b) Tone.OK else Tone.ERR
