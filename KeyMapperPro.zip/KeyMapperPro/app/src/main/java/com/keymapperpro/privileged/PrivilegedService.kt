package com.keymapperpro.privileged

import android.system.Os
import com.keymapperpro.IPrivilegedService
import kotlin.system.exitProcess

/**
 * UserService do Shizuku: executa como uid shell (2000), em processo próprio.
 * Instanciado pelo Shizuku com construtor sem argumentos.
 */
class PrivilegedService : IPrivilegedService.Stub() {
    private val injector: TouchInjector by lazy { TouchInjector() }

    override fun destroy() {
        try {
            injector.releaseAll()
        } catch (_: Throwable) {
        }
        exitProcess(0)
    }

    override fun getUid(): Int = Os.getuid()

    override fun touch(action: Int, pointerId: Int, x: Float, y: Float) {
        try {
            injector.touch(action, pointerId, x, y)
        } catch (_: Throwable) {
        }
    }

    override fun releaseAll() {
        try {
            injector.releaseAll()
        } catch (_: Throwable) {
        }
    }

    override fun exec(command: String): String = ShellRunner.run(command)
}
