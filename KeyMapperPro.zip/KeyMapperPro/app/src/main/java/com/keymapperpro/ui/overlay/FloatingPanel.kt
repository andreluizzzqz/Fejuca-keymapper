package com.keymapperpro.ui.overlay

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.keymapperpro.AppContainer
import com.keymapperpro.data.Keys
import com.keymapperpro.ui.theme.Bar
import com.keymapperpro.ui.theme.Chip
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.SliderRow
import com.keymapperpro.ui.theme.SwitchRow
import com.keymapperpro.ui.theme.clickableNoRipple
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Painel pequeno e arrastável. Recolhido = uma pílula; toque para expandir.
 * A janela é NOT_FOCUSABLE: não rouba o teclado do jogo.
 * Obs.: com o mouse capturado pelo mapeamento o cursor não existe — use o painel com o dedo.
 */
@Composable
fun FloatingPanel(
    c: AppContainer,
    onDrag: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onClose: () -> Unit,
    onEditor: () -> Unit,
    onOpenApp: () -> Unit,
) {
    // A escala altera a densidade, então a janela (WRAP_CONTENT) cresce junto, sem cortar.
    val scale by c.settings.flow.map { it.panelScale }.collectAsState(initial = 1f)
    val d = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(d.density * scale, d.fontScale)
    ) { PanelBody(c, onDrag, onDragEnd, onClose, onEditor, onOpenApp) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PanelBody(
    c: AppContainer,
    onDrag: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onClose: () -> Unit,
    onEditor: () -> Unit,
    onOpenApp: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val s by c.settings.flow.collectAsState(initial = com.keymapperpro.data.Settings())
    val enabled by c.engine.enabled.collectAsState()
    val profile by c.engine.profile.collectAsState()
    val profiles by c.repo.profiles.collectAsState(initial = emptyList())
    val devices by c.devices.devices.collectAsState()
    val ram by c.ram.info.collectAsState()
    val tel by c.telemetry.state.collectAsState()
    val err by c.engine.lastError.collectAsState()
    val disp by c.screen.state.collectAsState()
    val countdown by c.screen.countdown.collectAsState()
    val screenMsg by c.screen.message.collectAsState()
    var expanded by remember { mutableStateOf(false) }
    var resOpen by remember { mutableStateOf(false) }
    var ramMsg by remember { mutableStateOf<String?>(null) }

    DisposableAcquire(c)
    LaunchedEffect(resOpen) { if (resOpen) c.screen.refresh() }

    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .alpha(s.panelAlpha)
            .width(if (expanded) 270.dp else 150.dp)
            .clip(shape)
            .background(Gx.Surface)
            .border(1.dp, Gx.Blue.copy(alpha = 0.7f), shape)
            .animateContentSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // Cabeçalho (área de arrastar)
        Row(
            Modifier.fillMaxWidth().pointerInput(Unit) {
                detectDragGestures(onDragEnd = onDragEnd, onDragCancel = onDragEnd) { ch, d ->
                    ch.consume()
                    onDrag(d.x, d.y)
                }
            },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(if (enabled) "● MAPEANDO" else "○ PAUSADO", color = if (enabled) Gx.Ok else Gx.TextDim, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text(if (expanded) "▾" else "▸", color = Gx.Text, modifier = Modifier.clickableNoRipple { expanded = !expanded }.padding(horizontal = 8.dp))
            Text("✕", color = Gx.Err, modifier = Modifier.clickableNoRipple(onClose).padding(horizontal = 4.dp))
        }

        // Linha compacta: RAM / temperatura / FPS
        Text(
            buildString {
                if (s.panelShowRam) append("RAM ${ram.usedPct.toInt()}%  ")
                if (s.panelShowTemp) append(tel.batteryTempC?.let { "🌡${"%.0f".format(it)}°C  " } ?: "")
                append(tel.fps?.let { "${it.toInt()} FPS" } ?: "")
            }.trim().ifBlank { "—" },
            color = Gx.Text, style = MaterialTheme.typography.bodySmall,
        )

        AnimatedVisibility(expanded) {
            Column(
                Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SwitchRow("Mapeamento", enabled, { on -> c.engine.setEnabled(on) })
                err?.let { Text(it, color = Gx.Warn, style = MaterialTheme.typography.bodySmall) }

                val kb = devices.count { it.isKeyboard }
                val ms = devices.count { it.isMouse }
                Text(
                    "⌨ ${if (kb > 0) devices.first { it.isKeyboard }.name else "sem teclado"}\n🖱 ${if (ms > 0) devices.first { it.isMouse }.name else "sem mouse"}",
                    color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
                )

                Text("Perfil", color = Gx.TextDim, style = MaterialTheme.typography.bodySmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    profiles.forEach { p ->
                        Chip(p.name, p.id == s.activeProfileId) {
                            scope.launch {
                                if (enabled) c.engine.setEnabled(false)
                                c.settings.set(Keys.activeProfile, p.id)
                            }
                        }
                    }
                }

                profile?.let { p ->
                    SliderRow("Sens. X", p.sensX, { v -> scope.launch { c.engine.updateProfile { it.copy(sensX = v) } } }, 0.1f..5f)
                    SliderRow("Sens. Y", p.sensY, { v -> scope.launch { c.engine.updateProfile { it.copy(sensY = v) } } }, 0.1f..5f)
                    SwitchRow("Compensação de recuo", p.recoilEnabled, { v -> scope.launch { c.engine.updateProfile { it.copy(recoilEnabled = v) } } })
                }

                // Resolução
                GOutlined(if (resOpen) "Resolução ▴" else "Resolução ▾", { resOpen = !resOpen }, Modifier.fillMaxWidth())
                if (resOpen) {
                    Text("Atual: ${disp.curW}x${disp.curH} • ${disp.curDpi} dpi", color = Gx.Text, style = MaterialTheme.typography.bodySmall)
                    if (!c.screen.canApply) {
                        Text("Alterar exige Shizuku ou Root.", color = Gx.Warn, style = MaterialTheme.typography.bodySmall)
                    } else {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            c.screen.presets().filter { it.label.startsWith("Nativa").not() }.take(4).forEach { pr ->
                                Chip(pr.label.substringBefore(' '), false) { scope.launch { c.screen.apply(pr.w, pr.h, pr.dpi) } }
                            }
                        }
                        if (countdown > 0) {
                            GButton("Manter (${countdown}s)", { scope.launch { c.screen.confirm() } }, Modifier.fillMaxWidth())
                        }
                        GOutlined("Restaurar original", { scope.launch { c.screen.restore() } }, Modifier.fillMaxWidth())
                        screenMsg?.let { Text(it, color = Gx.TextDim, style = MaterialTheme.typography.bodySmall) }
                    }
                }

                // RAM
                Text("RAM ${ram.usedMb} / ${ram.totalMb} MB", color = Gx.Text, style = MaterialTheme.typography.bodySmall)
                Bar(ram.usedPct / 100f)
                GOutlined("Limpar memória", {
                    scope.launch {
                        val r = c.ram.optimize()
                        ramMsg = "+${r.freedMb} MB livres (${r.killed} apps)"
                    }
                }, Modifier.fillMaxWidth())
                ramMsg?.let { Text(it, color = Gx.TextDim, style = MaterialTheme.typography.bodySmall) }

                Text(tel.fps?.let { "FPS: ${it.toInt()}" } ?: "FPS: ${tel.fpsNote}", color = Gx.TextDim, style = MaterialTheme.typography.bodySmall)
                Text(
                    "Temp.: " + (tel.batteryTempC?.let { "${"%.1f".format(it)} °C (bateria)" } ?: "indisponível") +
                        (tel.thermalStatus?.let { " • térmico: $it" } ?: ""),
                    color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GOutlined("Editor", onEditor, Modifier.weight(1f))
                    GOutlined("Abrir app", onOpenApp, Modifier.weight(1f))
                }
                Spacer(Modifier.width(1.dp))
            }
        }
    }
}

@Composable
private fun DisposableAcquire(c: AppContainer) {
    androidx.compose.runtime.DisposableEffect(Unit) {
        c.ram.acquire()
        c.telemetry.acquire()
        onDispose {
            c.ram.release()
            c.telemetry.release()
        }
    }
}
