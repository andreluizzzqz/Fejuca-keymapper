package com.keymapperpro.service

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.keymapperpro.KeyMapperApp
import com.keymapperpro.core.GestureInjector
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Serviço de acessibilidade usado para: (1) gestos no modo sem root; (2) interceptar teclas do
 * teclado físico mesmo com o jogo em primeiro plano; (3) saber qual app está em primeiro plano.
 * Não lê o conteúdo da tela (canRetrieveWindowContent=false).
 */
class KeyMapperAccessibilityService : AccessibilityService() {
    companion object {
        val instance = MutableStateFlow<KeyMapperAccessibilityService?>(null)

        @Volatile
        var foregroundPackage: String? = null
    }

    var injector: GestureInjector? = null
        private set

    override fun onServiceConnected() {
        injector = GestureInjector(this)
        instance.value = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        foregroundPackage = pkg
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val container = (application as KeyMapperApp).container
        return container.engine.onKey(event)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        injector?.shutdown()
        injector = null
        instance.value = null
        return super.onUnbind(intent)
    }
}
