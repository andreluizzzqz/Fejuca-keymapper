package com.keymapperpro.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent

/**
 * Injeção sem root: gestos contínuos via AccessibilityService.dispatchGesture.
 * Cada gesto dura ~30 ms e é encadeado ao anterior (continueStroke), mantendo os dedos "pressionados".
 * Limitação: latência/precisão menores que Shizuku/Root, sobretudo para controle de câmera.
 */
class GestureInjector(private val svc: AccessibilityService) {
    private class P(var x: Float, var y: Float) {
        var lx = x
        var ly = y
        var stroke: GestureDescription.StrokeDescription? = null
        var releasing = false
        var final = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val pts = LinkedHashMap<Int, P>()
    private var busy = false
    private val segmentMs = 30L

    fun touch(action: Int, id: Int, x: Float, y: Float) {
        handler.post {
            when (action) {
                MotionEvent.ACTION_DOWN -> pts[id] = P(x, y)
                MotionEvent.ACTION_MOVE -> pts[id]?.let {
                    it.x = x
                    it.y = y
                }
                MotionEvent.ACTION_UP -> pts[id]?.let {
                    it.x = x
                    it.y = y
                    it.releasing = true
                }
            }
            pump()
        }
    }

    fun releaseAll() {
        handler.post {
            pts.values.forEach { it.releasing = true }
            pump()
        }
    }

    fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        pts.clear()
    }

    private fun pump() {
        if (busy || pts.isEmpty()) return
        val builder = GestureDescription.Builder()
        var n = 0
        val max = GestureDescription.getMaxStrokeCount()
        for (p in pts.values) {
            if (n >= max) break
            val path = Path().apply {
                moveTo(p.lx, p.ly)
                lineTo(p.x, p.y)
            }
            val willContinue = !p.releasing
            val stroke = p.stroke?.continueStroke(path, 0, segmentMs, willContinue)
                ?: GestureDescription.StrokeDescription(path, 0, segmentMs, willContinue)
            p.stroke = stroke
            p.lx = p.x
            p.ly = p.y
            if (p.releasing) p.final = true
            builder.addStroke(stroke)
            n++
        }
        busy = true
        val ok = try {
            svc.dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription) {
                    busy = false
                    pts.entries.removeAll { it.value.final }
                    pump()
                }

                override fun onCancelled(gestureDescription: GestureDescription) {
                    busy = false
                    pts.clear()
                }
            }, handler)
        } catch (e: Exception) {
            false
        }
        if (!ok) {
            busy = false
            pts.clear()
        }
    }
}
