package com.keymapperpro

import android.app.Application
import com.keymapperpro.core.ActivationManager
import com.keymapperpro.data.AppDb
import com.keymapperpro.data.ProfileRepository
import com.keymapperpro.data.SettingsStore
import com.keymapperpro.input.DeviceMonitor
import com.keymapperpro.input.MappingEngine
import com.keymapperpro.system.RamManager
import com.keymapperpro.system.ScreenManager
import com.keymapperpro.system.Telemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Container simples de dependências. Tudo é criado de forma lazy para a inicialização ser rápida. */
class AppContainer(val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val db by lazy { AppDb.build(app) }
    val repo by lazy { ProfileRepository(db.dao()) }
    val settings by lazy { SettingsStore(app) }
    val activation by lazy { ActivationManager(app, settings, scope) }
    val devices by lazy { DeviceMonitor(app) }
    val engine by lazy { MappingEngine(app, scope, repo, settings, activation) }
    val ram by lazy {
        RamManager(app, scope, activation, settings).also { r ->
            scope.launch { engine.profile.collect { r.gamePackage = it?.gamePackage } }
        }
    }
    val screen by lazy { ScreenManager(app, scope, activation, settings) }
    val telemetry by lazy { Telemetry(app, scope, activation) }

    /** Cria o perfil modelo na primeira execução e garante um perfil ativo válido. */
    fun bootstrap() {
        scope.launch(Dispatchers.IO) {
            val created = repo.ensureDefault()
            val s = settings.settingsOnce()
            if (created > 0) {
                settings.set(com.keymapperpro.data.Keys.activeProfile, created)
            } else if (s.activeProfileId < 0) {
                val first = repo.profiles.first().firstOrNull()
                if (first != null) settings.set(com.keymapperpro.data.Keys.activeProfile, first.id)
            }
        }
    }
}

class KeyMapperApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.bootstrap()
    }
}
