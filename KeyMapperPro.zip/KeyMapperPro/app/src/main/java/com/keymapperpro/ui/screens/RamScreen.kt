package com.keymapperpro.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.keymapperpro.ui.theme.Bar
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GCard
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.Notice
import com.keymapperpro.ui.theme.StatusRow
import com.keymapperpro.ui.theme.Tone
import kotlinx.coroutines.launch

@Composable
fun RamScreen() {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    val ram by c.ram.info.collectAsState()
    val history by c.ram.history.collectAsState()
    val apps by c.ram.apps.collectAsState()
    val note by c.ram.appsNote.collectAsState()
    val white by c.settings.ramWhitelist.collectAsState(initial = emptySet())
    var result by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        c.ram.acquire(withApps = true)
        onDispose { c.ram.release() }
    }

    ScreenColumn("Gerenciador de RAM", "Leitura real do sistema, atualizada a cada 2 s enquanto esta tela está aberta.") {
        GCard(title = "Memória") {
            StatusRow("Total", "${ram.totalMb} MB", Tone.OFF)
            StatusRow("Utilizada", "${ram.usedMb} MB (${ram.usedPct.toInt()}%)", if (ram.usedPct > 85) Tone.WARN else Tone.OK)
            StatusRow("Disponível", "${ram.availMb} MB", Tone.OK)
            Bar(ram.usedPct / 100f)
            if (ram.lowMemory) Notice("O sistema reporta pouca memória (lowMemory).", Tone.WARN)
        }

        GCard(title = "Histórico (últimos ~5 min)") {
            val line = Gx.Blue
            val fill = Gx.Purple.copy(alpha = 0.18f)
            Canvas(Modifier.fillMaxWidth().height(90.dp).clip(RoundedCornerShape(8.dp)).background(Gx.SurfaceHi)) {
                if (history.size < 2) return@Canvas
                val stepX = size.width / (history.size - 1)
                val path = Path()
                history.forEachIndexed { i, v ->
                    val x = i * stepX
                    val y = size.height * (1f - (v / 100f).coerceIn(0f, 1f))
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val area = Path().apply {
                    addPath(path)
                    lineTo(size.width, size.height); lineTo(0f, size.height); close()
                }
                drawPath(area, fill)
                drawPath(path, line, style = Stroke(width = 3f))
                drawLine(Gx.Outline, Offset(0f, size.height * 0.15f), Offset(size.width, size.height * 0.15f), 1f)
            }
            Text(
                "Mín ${history.minOrNull()?.toInt() ?: 0}% • Máx ${history.maxOrNull()?.toInt() ?: 0}% • Amostras ${history.size}",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
        }

        GCard(title = "Otimização segura") {
            Text(
                "Pede ao Android para encerrar apenas processos em SEGUNDO PLANO de apps comuns (killBackgroundProcesses). " +
                    "Nunca toca em sistema, teclado, tela inicial, serviços de acessibilidade, Shizuku, este app, o jogo em primeiro plano " +
                    "nem apps da sua lista de proteção. O Android recria o que precisar, então o ganho é temporário — " +
                    "e liberar RAM não aumenta o FPS por si só: só ajuda se o aparelho estava sem memória livre.",
                color = Gx.TextDim, style = MaterialTheme.typography.bodySmall,
            )
            GButton(if (busy) "Otimizando…" else "Otimizar memória", { confirm = true }, Modifier.fillMaxWidth(), enabled = !busy)
            if (confirm) {
                Notice("Confirmar? Apps em segundo plano (ex.: players de música, mensageiros) podem parar de atualizar até serem abertos de novo.", Tone.WARN)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GButton("Confirmar", {
                        confirm = false; busy = true
                        scope.launch {
                            val r = c.ram.optimize()
                            result = "Liberado: ${r.freedMb} MB • ${r.note}"
                            busy = false
                        }
                    }, Modifier.weight(1f))
                    GOutlined("Cancelar", { confirm = false }, Modifier.weight(1f))
                }
            }
            result?.let { Text(it, color = Gx.Text, style = MaterialTheme.typography.bodySmall) }
        }

        GCard(title = "Consumo por aplicativo") {
            note?.let { Notice(it, Tone.WARN) }
            apps.take(30).forEach { a ->
                val prot = a.protectedReason
                val isWhite = a.pkg in white
                Row(
                    Modifier.fillMaxWidth().clickable(enabled = prot == null) {
                        scope.launch { c.settings.setRamWhitelist(if (isWhite) white - a.pkg else white + a.pkg) }
                    }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(a.label, color = Gx.Text, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            when {
                                prot != null -> "Protegido • $prot"
                                isWhite -> "Na sua lista de proteção"
                                else -> "Segundo plano • toque para proteger"
                            },
                            color = if (prot != null || isWhite) Gx.Ok else Gx.TextDim, style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("${a.pssMb.toInt()} MB", color = Gx.Text, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
