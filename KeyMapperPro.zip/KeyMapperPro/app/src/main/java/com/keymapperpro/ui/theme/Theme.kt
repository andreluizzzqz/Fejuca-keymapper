package com.keymapperpro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object Gx {
    val Bg = Color(0xFF0A0C16)
    val Surface = Color(0xFF121528)
    val SurfaceHi = Color(0xFF1A1E38)
    val Outline = Color(0xFF2A2F55)
    val Blue = Color(0xFF4C8DFF)
    val Purple = Color(0xFF9D5CFF)
    val Ok = Color(0xFF3DDC97)
    val Warn = Color(0xFFFFB84D)
    val Err = Color(0xFFFF5C7A)
    val Text = Color(0xFFE8EAFF)
    val TextDim = Color(0xFF8E93B8)
    val Gradient = Brush.horizontalGradient(listOf(Blue, Purple))
}

private val scheme = darkColorScheme(
    primary = Gx.Blue,
    onPrimary = Color.White,
    secondary = Gx.Purple,
    onSecondary = Color.White,
    tertiary = Gx.Ok,
    background = Gx.Bg,
    onBackground = Gx.Text,
    surface = Gx.Surface,
    onSurface = Gx.Text,
    surfaceVariant = Gx.SurfaceHi,
    onSurfaceVariant = Gx.TextDim,
    outline = Gx.Outline,
    error = Gx.Err,
)

private val type = Typography(
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 24.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 15.sp),
    bodyMedium = TextStyle(fontSize = 13.sp),
    bodySmall = TextStyle(fontSize = 12.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp),
)

@Composable
fun KeyMapperTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}
