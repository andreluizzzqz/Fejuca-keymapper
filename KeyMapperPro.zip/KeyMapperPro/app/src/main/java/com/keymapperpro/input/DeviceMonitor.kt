package com.keymapperpro.input

import android.content.Context
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import kotlinx.coroutines.flow.MutableStateFlow

data class InputDev(val id: Int, val name: String, val isKeyboard: Boolean, val isMouse: Boolean, val vendor: Int, val product: Int)

/** Reconhece teclados e mouses (USB ou Bluetooth) em tempo real via InputManager. */
class DeviceMonitor(ctx: Context) {
    private val im = ctx.getSystemService(Context.INPUT_SERVICE) as InputManager
    val devices = MutableStateFlow<List<InputDev>>(emptyList())

    private val listener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = scan()
        override fun onInputDeviceRemoved(deviceId: Int) = scan()
        override fun onInputDeviceChanged(deviceId: Int) = scan()
    }

    init {
        im.registerInputDeviceListener(listener, Handler(Looper.getMainLooper()))
        scan()
    }

    fun scan() {
        val out = ArrayList<InputDev>()
        for (id in im.inputDeviceIds) {
            val d = im.getInputDevice(id) ?: continue
            if (d.isVirtual) continue
            val src = d.sources
            val kb = (src and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
                d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
            val mouse = (src and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (src and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE ||
                (src and InputDevice.SOURCE_TOUCHPAD) == InputDevice.SOURCE_TOUCHPAD
            if (kb || mouse) out += InputDev(id, d.name, kb, mouse, d.vendorId, d.productId)
        }
        devices.value = out
    }

    val keyboards get() = devices.value.filter { it.isKeyboard }
    val mice get() = devices.value.filter { it.isMouse }
}
