package com.keymapperpro.ui.overlay

import android.view.KeyEvent as AKeyEvent
import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusTarget
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.keymapperpro.data.ControlEntity
import com.keymapperpro.data.ControlType
import com.keymapperpro.data.MouseBtn
import com.keymapperpro.ui.theme.Chip
import com.keymapperpro.ui.theme.GButton
import com.keymapperpro.ui.theme.GOutlined
import com.keymapperpro.ui.theme.Gx
import com.keymapperpro.ui.theme.SliderRow
import com.keymapperpro.ui.theme.SwitchRow
import kotlin.math.min
import kotlin.math.roundToInt

fun keyName(code: Int): String =
    if (code == 0) "—" else AKeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").replace('_', ' ')

fun mouseName(b: Int): String = when (b) {
    0 -> "—"
    MotionEvent.BUTTON_PRIMARY -> "Mouse esquerdo"
    MotionEvent.BUTTON_SECONDARY -> "Mouse direito"
    MotionEvent.BUTTON_TERTIARY -> "Mouse meio"
    MotionEvent.BUTTON_BACK -> "Mouse voltar"
    MotionEvent.BUTTON_FORWARD -> "Mouse avançar"
    MouseBtn.SCROLL_UP -> "Roda ↑"
    MouseBtn.SCROLL_DOWN -> "Roda ↓"
    else -> "Mouse #$b"
}

private enum class Target { MAIN, UP, DOWN, LEFT, RIGHT, MOUSE }

/**
 * Editor visual. No modo overlay o fundo é transparente (você vê o jogo por trás) e o
 * painel de propriedades fica no canto. Todas as alterações são gravadas no banco ao soltar.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ControlEditor(
    profileId: Long,
    controls: List<ControlEntity>,
    onAdd: (ControlEntity) -> Unit,
    onSave: (ControlEntity) -> Unit,
    onDelete: (ControlEntity) -> Unit,
    overlay: Boolean,
    onClose: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val local: SnapshotStateList<ControlEntity> = remember(controls) { controls.toMutableStateList() }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var listening by remember { mutableStateOf<Target?>(null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    fun update(c: ControlEntity, persist: Boolean) {
        val i = local.indexOfFirst { it.id == c.id }
        if (i >= 0) local[i] = c
        if (persist) onSave(c)
    }

    val sel = local.firstOrNull { it.id == selectedId }

    fun assignKey(code: Int) {
        val c = sel ?: return
        val t = listening ?: return
        val n = when (t) {
            Target.MAIN -> c.copy(keyCode = code)
            Target.UP -> c.copy(keyUp = code)
            Target.DOWN -> c.copy(keyDown = code)
            Target.LEFT -> c.copy(keyLeft = code)
            Target.RIGHT -> c.copy(keyRight = code)
            Target.MOUSE -> return
        }
        listening = null
        update(n, true)
    }

    fun assignMouse(btn: Int) {
        val c = sel ?: return
        if (listening != Target.MOUSE) return
        listening = null
        update(c.copy(mouseButton = btn), true)
    }

    BoxWithConstraints(
        modifier
            .fillMaxSize()
            .background(if (overlay) Color(0x66000000) else Gx.Bg)
            .focusRequester(focus)
            .focusTarget()
            .onPreviewKeyEvent { e ->
                val l = listening
                if (l != null && l != Target.MOUSE && e.type == KeyEventType.KeyDown) {
                    if (e.key.nativeKeyCode == AKeyEvent.KEYCODE_ESCAPE) listening = null
                    else assignKey(e.key.nativeKeyCode)
                    true
                } else false
            }
            .pointerInput(listening) {
                if (listening != Target.MOUSE) return@pointerInput
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent()
                        val isMouse = ev.changes.any { it.type == PointerType.Mouse }
                        if (!isMouse) continue
                        if (ev.type == PointerEventType.Scroll) {
                            val dy = ev.changes.first().scrollDelta.y
                            assignMouse(if (dy < 0) MouseBtn.SCROLL_UP else MouseBtn.SCROLL_DOWN)
                        } else if (ev.type == PointerEventType.Press) {
                            val b = ev.buttons
                            val code = when {
                                b.isPrimaryPressed -> MotionEvent.BUTTON_PRIMARY
                                b.isSecondaryPressed -> MotionEvent.BUTTON_SECONDARY
                                b.isTertiaryPressed -> MotionEvent.BUTTON_TERTIARY
                                b.isBackPressed -> MotionEvent.BUTTON_BACK
                                b.isForwardPressed -> MotionEvent.BUTTON_FORWARD
                                else -> 0
                            }
                            if (code != 0) assignMouse(code)
                        }
                    }
                }
            }
    ) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        val m = min(w, h)
        val density = LocalDensity.current

        // ---- controles ----
        for (c in local) {
            val diameter = c.size * m
            val isSel = c.id == selectedId
            val color = if (c.type == ControlType.CAMERA) Gx.Purple else Gx.Blue
            Box(
                Modifier
                    .offset { IntOffset((c.x * w - diameter / 2).roundToInt(), (c.y * h - diameter / 2).roundToInt()) }
                    .size(with(density) { diameter.toDp() })
                    .alpha(c.alpha.coerceIn(0.2f, 1f))
                    .clip(CircleShape)
                    .background(color.copy(alpha = if (c.type == ControlType.CAMERA) 0.10f else 0.30f))
                    .border(if (isSel) 4.dp else 2.dp, if (isSel) Color.White else color, CircleShape)
                    .pointerInput(c.id) {
                        detectDragGestures(
                            onDragStart = { selectedId = c.id },
                            onDragEnd = { local.firstOrNull { it.id == c.id }?.let { onSave(it) } },
                            onDragCancel = { local.firstOrNull { it.id == c.id }?.let { onSave(it) } },
                        ) { change, drag ->
                            change.consume()
                            val cur = local.firstOrNull { it.id == c.id } ?: return@detectDragGestures
                            update(
                                cur.copy(
                                    x = (cur.x + drag.x / w).coerceIn(0f, 1f),
                                    y = (cur.y + drag.y / h).coerceIn(0f, 1f),
                                ), false
                            )
                        }
                    }
                    .pointerInput(c.id + 1) {
                        androidx.compose.foundation.gestures.detectTapGestures { selectedId = c.id }
                    },
                contentAlignment = Alignment.Center,
            ) {
                val text = when (c.type) {
                    ControlType.JOYSTICK -> "WASD"
                    ControlType.CAMERA -> "CÂMERA"
                    else -> c.label.ifBlank { if (c.mouseButton != 0) mouseName(c.mouseButton) else keyName(c.keyCode) }
                }
                Text(text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
            }
        }

        // ---- barra superior ----
        Row(
            Modifier.align(Alignment.TopCenter).padding(8.dp).clip(RoundedCornerShape(14.dp))
                .background(Gx.Surface.copy(alpha = 0.95f)).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            GButton("+ Botão", { onAdd(ControlEntity(profileId = profileId, label = "", x = 0.5f, y = 0.5f, size = 0.10f)) })
            GOutlined("+ Joystick", {
                if (local.none { it.type == ControlType.JOYSTICK })
                    onAdd(ControlEntity(profileId = profileId, type = ControlType.JOYSTICK, label = "WASD", x = 0.17f, y = 0.70f, size = 0.30f))
            }, enabled = local.none { it.type == ControlType.JOYSTICK })
            GOutlined("+ Câmera", {
                if (local.none { it.type == ControlType.CAMERA })
                    onAdd(ControlEntity(profileId = profileId, type = ControlType.CAMERA, label = "Câmera", x = 0.72f, y = 0.5f, size = 0.8f, alpha = 0.3f))
            }, enabled = local.none { it.type == ControlType.CAMERA })
            if (onClose != null) GButton("Concluir", onClose)
        }

        // ---- propriedades ----
        if (sel != null) {
            Column(
                Modifier.align(if (overlay) Alignment.BottomStart else Alignment.BottomCenter)
                    .padding(8.dp).fillMaxWidth(if (overlay) 0.46f else 1f)
                    .clip(RoundedCornerShape(16.dp)).background(Gx.Surface.copy(alpha = 0.97f))
                    .border(1.dp, Gx.Outline, RoundedCornerShape(16.dp))
                    .verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    when (sel.type) { ControlType.JOYSTICK -> "Joystick (movimento)"; ControlType.CAMERA -> "Área da câmera"; else -> "Botão" },
                    color = Gx.Text, style = MaterialTheme.typography.titleMedium,
                )
                if (sel.type == ControlType.BUTTON) {
                    OutlinedTextField(
                        value = sel.label, onValueChange = { update(sel.copy(label = it.take(12)), true) },
                        label = { Text("Rótulo") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        GOutlined(if (listening == Target.MAIN) "Pressione a tecla…" else "Tecla: ${keyName(sel.keyCode)}", { listening = Target.MAIN })
                        GOutlined(if (listening == Target.MOUSE) "Clique/role o mouse…" else "Mouse: ${mouseName(sel.mouseButton)}", { listening = Target.MOUSE })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GOutlined("Limpar tecla", { update(sel.copy(keyCode = 0), true) }, enabled = sel.keyCode != 0)
                        GOutlined("Limpar mouse", { update(sel.copy(mouseButton = 0), true) }, enabled = sel.mouseButton != 0)
                    }
                    SwitchRow(
                        "Botão de disparo", sel.isFire, { update(sel.copy(isFire = it), true) },
                        "A compensação de recuo age enquanto ele estiver pressionado.",
                    )
                }
                if (sel.type == ControlType.JOYSTICK) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("↑ ${keyName(sel.keyUp)}", listening == Target.UP) { listening = Target.UP }
                        Chip("↓ ${keyName(sel.keyDown)}", listening == Target.DOWN) { listening = Target.DOWN }
                        Chip("← ${keyName(sel.keyLeft)}", listening == Target.LEFT) { listening = Target.LEFT }
                        Chip("→ ${keyName(sel.keyRight)}", listening == Target.RIGHT) { listening = Target.RIGHT }
                    }
                    Text("Toque numa direção e pressione a nova tecla.", color = Gx.TextDim, style = MaterialTheme.typography.bodySmall)
                }
                if (listening != null) {
                    Text("Aguardando entrada… (Esc cancela)", color = Gx.Warn, style = MaterialTheme.typography.bodySmall)
                    GOutlined("Cancelar", { listening = null })
                }
                val maxSize = if (sel.type == ControlType.CAMERA) 1.0f else 0.6f
                SliderRow("Tamanho", sel.size, { update(sel.copy(size = it), false) }, 0.04f..maxSize, { "${(it * 100).roundToInt()}%" }) { onSave(sel) }
                SliderRow("Transparência", sel.alpha, { update(sel.copy(alpha = it), false) }, 0.2f..1f, { "${(it * 100).roundToInt()}%" }) { onSave(sel) }
                SliderRow("Posição X", sel.x, { update(sel.copy(x = it), false) }, 0f..1f, { "${(it * 100).roundToInt()}%" }) { onSave(sel) }
                SliderRow("Posição Y", sel.y, { update(sel.copy(y = it), false) }, 0f..1f, { "${(it * 100).roundToInt()}%" }) { onSave(sel) }
                GOutlined("Excluir controle", {
                    onDelete(sel)
                    selectedId = null
                })
            }
        }
    }
}
