package com.keymapperpro.privileged

import android.net.LocalServerSocket
import android.net.LocalSocket
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.security.MessageDigest
import kotlin.system.exitProcess

/**
 * Daemon executado como root via `su -c app_process ...`.
 * Escuta em um socket abstrato; aceita apenas o uid do app dono e exige o token compartilhado.
 *
 * Protocolo (DataStream): cliente envia token (UTF); servidor responde PROTOCOL (int).
 * Depois: byte op -> 1 touch(int action,int id,float x,float y) | 2 releaseAll | 3 exec(UTF) -> UTF | 0 sair.
 */
object RootServer {
    const val PROTOCOL = 1
    fun socketName(uid: Int) = "keymapperpro_root_$uid"

    @JvmStatic
    fun main(args: Array<String>) {
        if (args.size < 2) return
        val token = args[0]
        val ownerUid = args[1].toInt()
        val server = try {
            LocalServerSocket(socketName(ownerUid))
        } catch (e: IOException) {
            return // já existe um servidor em execução
        }
        val injector = TouchInjector()
        while (true) {
            val s = try {
                server.accept()
            } catch (e: IOException) {
                break
            }
            try {
                handle(s, token, ownerUid, injector)
            } catch (_: Throwable) {
            } finally {
                try {
                    injector.releaseAll()
                } catch (_: Throwable) {
                }
                try {
                    s.close()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun handle(s: LocalSocket, token: String, ownerUid: Int, injector: TouchInjector) {
        if (s.peerCredentials.uid != ownerUid) return
        val input = DataInputStream(s.inputStream.buffered())
        val out = DataOutputStream(BufferedOutputStream(s.outputStream))
        val sent = input.readUTF()
        if (!MessageDigest.isEqual(sent.toByteArray(), token.toByteArray())) return
        out.writeInt(PROTOCOL)
        out.flush()
        while (true) {
            when (input.readByte().toInt()) {
                1 -> {
                    val a = input.readInt()
                    val id = input.readInt()
                    val x = input.readFloat()
                    val y = input.readFloat()
                    injector.touch(a, id, x, y)
                }
                2 -> injector.releaseAll()
                3 -> {
                    val cmd = input.readUTF()
                    out.writeUTF(ShellRunner.run(cmd))
                    out.flush()
                }
                0 -> {
                    injector.releaseAll()
                    exitProcess(0)
                }
                else -> return
            }
        }
    }
}
