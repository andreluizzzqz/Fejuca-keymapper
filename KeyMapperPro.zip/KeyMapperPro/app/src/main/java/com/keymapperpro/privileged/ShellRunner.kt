package com.keymapperpro.privileged

import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Executa um comando `sh -c` e devolve "<exitCode>\n<saida>". Usado dentro do processo privilegiado. */
object ShellRunner {
    fun run(command: String, timeoutMs: Long = 20_000): String {
        return try {
            val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val buf = StringBuilder()
            val reader = thread(isDaemon = true) {
                try {
                    p.inputStream.bufferedReader().forEachLine { buf.appendLine(it) }
                } catch (_: Exception) {
                }
            }
            val finished = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!finished) p.destroyForcibly()
            reader.join(500)
            val code = if (finished) p.exitValue() else 124
            "$code\n${buf.toString().trimEnd()}"
        } catch (e: Exception) {
            "127\n${e.message}"
        }
    }
}
