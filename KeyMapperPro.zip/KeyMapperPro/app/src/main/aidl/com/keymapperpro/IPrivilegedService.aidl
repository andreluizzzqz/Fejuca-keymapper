package com.keymapperpro;

// Serviço executado em processo privilegiado (shell via Shizuku).
interface IPrivilegedService {
    // Reservado pelo Shizuku: encerra o processo do serviço.
    void destroy() = 16777114;

    int getUid() = 1;

    // action = MotionEvent.ACTION_DOWN / MOVE / UP; pointerId 0..31; x,y em pixels reais da tela.
    oneway void touch(int action, int pointerId, float x, float y) = 2;

    oneway void releaseAll() = 3;

    // Retorna "<exitCode>\n<saida>".
    String exec(String command) = 4;
}
