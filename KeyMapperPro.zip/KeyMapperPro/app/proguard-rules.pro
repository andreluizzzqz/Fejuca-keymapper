# Classes carregadas por nome em processos privilegiados (Shizuku UserService / servidor root)
-keep class com.keymapperpro.privileged.** { *; }
-keep class com.keymapperpro.IPrivilegedService { *; }
-keep class com.keymapperpro.IPrivilegedService$Stub { *; }
-keep class org.lsposed.hiddenapibypass.** { *; }
-keep class rikka.shizuku.** { *; }
